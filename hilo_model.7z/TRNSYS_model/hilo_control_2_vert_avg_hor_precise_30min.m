%%%% This matlab file includes the modelling of the roof and floor TABS, the ventilation system, e-glass and occupancy
%%%% schedule for HiLo.

%%%% Parts marked by:

%%%%%% HORIZONTAL average/no average difference START %%%%%%
%%%%%% HORIZONTAL average/no average difference END %%%%%%

%%%% show where the differences between the horizontally detailed and the horizontally averaged
%%%% file are.

mFileErrorCode = 100;    % Beginning of the m-file


% --- Process Inputs and global parameters -----------------------------------------------------------------------------
% ----------------------------------------------------------------------------------------------------------------------

nI = trnInfo(3);
nO = trnInfo(6);

% save inputs into vector
MyInputs=trnInputs(1:nI);



%% General Global Variables and Inputs %%


% Read in data from Excel sheet and store values into parameter %

[~,~,FL_layers] = xlsread('HiLo_model_specs_inputs.xlsx',1);    % vertical floor TABS geometry data

[~,~,FL_geometry] = xlsread('HiLo_model_specs_inputs.xlsx',2);  % horizontal floor TABS geometry data

[~,~,RO_layers] = xlsread('HiLo_model_specs_inputs.xlsx',3);    % vertical roof TABS geometry data

[~,~,RO_geometry] = xlsread('HiLo_model_specs_inputs.xlsx',4);  % horizontal roof TABS geometry data

[~,~,ventilation] = xlsread('HiLo_model_specs_inputs.xlsx',5);  % ventilation system inputs

[~,~,e_glass] = xlsread('HiLo_model_specs_inputs.xlsx',6);      % electrochromic glass inputs

[~,~,occupancy] = xlsread('HiLo_model_specs_inputs.xlsx',7);    % occupancy schedule




dt=60*30;       % time step [s]

c_w=4186;           % water specific heat capacity [J/(kg K)]
lambda_w=0.59;      % water thermal conductivity [W/(m K)]

h_ceil_heat=6;      % convective heat transfer for ceiling heating mode [W/(m^2 k)]
h_ceil_cool=8.92;   % convective heat transfer for ceiling cooling mode [W/(m^2 k)]
h_wall=8;           % convective heat transfer for wall heating/cooling mode [W/(m^2 k)]
h_floor_heat=8.92;  % convective heat transfer for floor heating mode [W/(m^2 k)]
h_floor_cool=7;     % convective heat transfer for ceiling cooling mode [W/(m^2 k)]




%% Floor TABS %%


%%% Global parameters and constants %%%

FL_numLayers=FL_layers{1,2}+1;          % number of layers
FL_numLoops=FL_geometry{1,2};           % number of loops
FL_numSubsections=FL_geometry{1,4};     % number of subsections

FL_theta_sw(1:FL_numLoops)=FL_geometry{1,6};    % supply water temperature [�C]
FL_m_dot=FL_geometry{1,8}*0.016667;             % supply water mass flow, from [L/min] to [kg/s]

FL_pipe_layer_location=FL_layers{3,2}+1;        % layer position of pipe

FL_d_x=FL_layers{1,6};          % pipe spacing [m]
FL_delta=FL_layers{1,4};        % pipe outside diameter [m]
FL_d_p=FL_layers{3,4};          % pipe thickness [m]

FL_lambda_p=FL_layers{3,6};                             % pipe thermal conductivity [W/(m K)]
FL_lambda_s=FL_layers{8+FL_pipe_layer_location,5};      % slab (pipe layer) thermal conductivity [W/(m K)]


% Store vertical layer values into matrices %

FL_rho(1:FL_numLayers-1)=0;
FL_Cp(1:FL_numLayers-1)=0;
FL_lambda(1:FL_numLayers-1)=0;
FL_d_fix(1:FL_numLayers-1)=0;

for k=1:FL_numLayers-1
    
    FL_rho(k)=FL_layers{9+k,3};         % layer density [kg/m^3]
    
    FL_Cp(k)=FL_layers{9+k,4};          % layer specific heat capacity [J/(kg K)]
    
    FL_lambda(k)=FL_layers{9+k,5};      % layer thermal conductivity [W/(m K)]
    
    FL_d_fix(k)=FL_layers{9+k,6};       % layer thickness [m]
    
end



% Store loop values into matrices %

FL_A_fl(1:FL_numLoops,1:FL_numSubsections)=0;
FL_A_ta(1:FL_numLoops,1:FL_numSubsections)=0;
FL_alpha(1:FL_numLoops,1:FL_numSubsections)=0;
FL_p_len(1:FL_numLoops,1:FL_numSubsections)=0;
FL_d_var(1:FL_numLoops,1:FL_numSubsections)=0;
FL_m_dot_sp(1:FL_numLoops,1:FL_numSubsections)=0;
FL_m_dot_sp_tot(1:FL_numLoops)=0;
FL_A_fl_tot(1:FL_numLoops)=0;
FL_A_ta_tot(1:FL_numLoops)=0;

for i=1:FL_numLoops
    for j=1:FL_numSubsections
        
        FL_A_fl(i,j)=FL_geometry{(i-1)*FL_numSubsections+5+j,2};        % floor area of subsection [m^2]
        
        FL_A_ta(i,j)=FL_geometry{(i-1)*FL_numSubsections+5+j,6};        % activated TABS area of subsection [m^2]
        
        FL_A_fl_tot(i)=FL_A_fl_tot(i)+FL_A_fl(i,j);                     % total floor area of loop [m^2]
        
        FL_A_ta_tot(i)=FL_A_ta_tot(i)+FL_A_ta(i,j);                     % total activated TABS area of loop [m^2]
        
        FL_alpha(i,j)=FL_geometry{(i-1)*FL_numSubsections+5+j,3};       % slope of subsection [�]
        
        FL_p_len(i,j)=FL_geometry{(i-1)*FL_numSubsections+5+j,4};       % pipe length per subsection [m]
        
        FL_d_var(i,j)=FL_geometry{(i-1)*FL_numSubsections+5+j,5};       % varying thickness across subsections of layer at position: pipe_layer_location-2 [m]
        
        FL_m_dot_sp(i,j)=FL_m_dot/(FL_d_x*FL_p_len(i,j));               % specific mass flow per subsection [kg/(s m^2)]
        
        FL_m_dot_sp_tot(i)=FL_m_dot/(FL_d_x*sum(FL_p_len(i,:)));        % specific mass flow per loop [kg/(s m^2)]
        
    end
end


%%%%%%% HORIZONTAL average/no average difference START %%%%%%
% FL_A_fl(:,1)=FL_A_fl_tot(:);
% FL_A_ta(:,1)=FL_A_ta_tot(:);
% 
% FL_alpha_avg(1:FL_numLoops)=0;
% for i=1:FL_numLoops
%     for j=1:FL_numSubsections
%         FL_alpha_avg(i)=FL_alpha_avg(i)+FL_alpha(i,j)*FL_A_fl(i,j)/FL_A_fl_tot(i);
%     end
% end
% FL_alpha(:,1)=FL_alpha_avg(:);
% 
% 
% FL_d_var_avg(1:FL_numLoops)=0;
% for i=1:FL_numLoops
%     for j=1:FL_numSubsections
%         FL_d_var_avg(i)=FL_d_var_avg(i)+FL_d_var(i,j)*FL_A_fl(i,j)/FL_A_fl_tot(i);
%     end
% end
% FL_d_var(:,1)=FL_d_var_avg(:);
% 
% 
% for i=1:FL_numLoops
%     FL_p_len(i,1)=sum(FL_p_len(i,:));
% end
% 
% FL_numSubsections=1;
%%%%%%% HORIZONTAL average/no average difference END %%%%%%


% Calculate R and C values %

FL_R_z(1:FL_numLoops)=0;
FL_R_w(1:FL_numLoops,1:FL_numSubsections)=0;
FL_R_p(1:FL_numLoops,1:FL_numSubsections)=0;
FL_R_x(1:FL_numLoops,1:FL_numSubsections)=0;
FL_R_t(1:FL_numLoops,1:FL_numSubsections)=0;
FL_R_layer_s(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers-1)=0;
FL_R_layer_u(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers-1)=0;
FL_C_layer_s(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers-1)=0;
FL_C_layer_u(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers-1)=0;
FL_sum_quot__1__R_t(1:FL_numLoops,1)=0;

for i=1:FL_numLoops
    for j=1:FL_numSubsections
        for k=1:FL_numLayers-1
            
            % Calculate horizontal resistance values %
            
            FL_R_z(i)=FL_A_fl_tot(i)/FL_A_ta_tot(i)*1/(2*FL_m_dot_sp_tot(i)*c_w);                                                           % resistance: supply water temp - mean water temp  [(m^2 K)/W)]
            
            FL_R_w(i,j)=FL_A_fl_tot(i)/FL_A_ta(i,j)*FL_d_x/(pi*lambda_w)*(49.03+4.17+4/pi*(FL_m_dot_sp(i,j)*c_w*FL_d_x)/lambda_w)^(-1/3); % resistance: mean water temp (pipe circular middle) - pipe inside wall surface temp [(m^2 K)/W)]
            
            FL_R_p(i,j)=FL_A_fl_tot(i)/FL_A_ta(i,j)*FL_d_x*log(FL_delta/(FL_delta-2*FL_d_p))/(2*FL_lambda_p*pi);                        % resistance: inside pipe wall surface temp - outside pipe wall surface temp [(m^2 K)/W)]
            
            FL_R_x(i,j)=FL_A_fl_tot(i)/FL_A_ta(i,j)*FL_d_x*1/3*(FL_d_x/(pi*FL_delta))/(2*FL_lambda_s*pi);                               % resistance: outside pipe wall surface temp - core temp  [(m^2 K)/W)]
            
            FL_R_t(i,j)=FL_R_w(i,j)+FL_R_p(i,j)+FL_R_x(i,j);                                                                            % total resistance: mean water temp - core temp [(m^2 K)/W)]
            
            
            % Calculate resistance value matrix for vertical layers %
            
            FL_R_layer_s(i,j,k)=FL_A_fl_tot(i)/FL_A_ta(i,j)*FL_d_fix(k)/FL_lambda(k);                                                                   % activated TABS layer resistance [(m^2 K)/W)]
            
            FL_R_layer_s(i,j,FL_pipe_layer_location-2)=FL_A_fl_tot(i)/FL_A_ta(i,j)*FL_d_var(i,j)/FL_lambda(FL_pipe_layer_location-2);                   % activated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            FL_R_layer_u(i,j,k)=FL_A_fl_tot(i)/(FL_A_fl(i,j)-FL_A_ta(i,j))*FL_d_fix(k)/FL_lambda(k);                                                    % unactivated TABS layer resistance [(m^2 K)/W)]
            
            FL_R_layer_u(i,j,FL_pipe_layer_location-2)=FL_A_fl_tot(i)/(FL_A_fl(i,j)-FL_A_ta(i,j))*FL_d_var(i,j)/FL_lambda(FL_pipe_layer_location-2);    % unactivated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            % Calculate capacitance value matrix for vertical layers %
            
            if k==1 || k==2 || k==3 || k==FL_numLayers-1            % top side: all 3 layers merged and averaged to surface layer, bottom side: 1 layer is surface layer (capacitance extends over subsections to whole loop -> no area ratio)
                
                FL_C_layer_s(i,j,k)=FL_d_fix(k)*FL_rho(k)*FL_Cp(k); % activated TABS layer capacitance [W/(m^2 K))]
                
                FL_C_layer_u(i,j,k)=FL_C_layer_s(i,j,k);            % unactivated TABS layer capacitance [W/(m^2 K))]
                
            elseif k==FL_pipe_layer_location-2 % for layer with varying thickness d_var
                
                FL_C_layer_s(i,j,k)=FL_d_var(i,j)*FL_rho(k)*FL_Cp(k);   % activated TABS layer capacitance [W/(m^2 K))]
                
                FL_C_layer_u(i,j,k)=FL_C_layer_s(i,j,k);                % unactivated TABS layer capacitance [W/(m^2 K))]
                
            end
        end
        
        FL_sum_quot__1__R_t(i)=FL_sum_quot__1__R_t(i)+(1/FL_R_t(i,j));      % summing up all the 1/R_t from each subsection per loop for later usage in calculations [W/(m^2 K))]
        
    end
end


% merging and averaging layers %

FL_numLayers=FL_numLayers-2;  % losing two layers since merging
FL_pipe_layer_location=FL_pipe_layer_location-2;  % moving up pipe layer location

for i=1:FL_numLoops
    for j=1:FL_numSubsections
        
        % adding resistance and capacitance values of layers to be merged
        % 1, 2 and 3 into position 1
        FL_R_layer_s(i,j,1)=FL_R_layer_s(i,j,1)+FL_R_layer_s(i,j,2)+FL_R_layer_s(i,j,3);
        FL_R_layer_u(i,j,1)=FL_R_layer_u(i,j,1)+FL_R_layer_u(i,j,2)+FL_R_layer_u(i,j,3);
        FL_C_layer_s(i,j,1)=FL_C_layer_s(i,j,1)+FL_C_layer_s(i,j,2)+FL_C_layer_s(i,j,3);
        FL_C_layer_u(i,j,1)=FL_C_layer_u(i,j,1)+FL_C_layer_u(i,j,2)+FL_C_layer_u(i,j,3);
        
        % 4 into position 2
        FL_R_layer_s(i,j,2)=FL_R_layer_s(i,j,4);
        FL_R_layer_u(i,j,2)=FL_R_layer_u(i,j,4);
        FL_C_layer_s(i,j,2)=FL_C_layer_s(i,j,4);
        FL_C_layer_u(i,j,2)=FL_C_layer_u(i,j,4);
        
        
    end
end


%%%% Convective heat transfer coefficient calculations  %%%%

%%% lower surface (room 2) %%%
FL_h_heat_r2(1:FL_numLoops,1:FL_numSubsections)=0;
FL_h_cool_r2(1:FL_numLoops,1:FL_numSubsections)=0;
for i=1:FL_numLoops
    for j=1:FL_numSubsections
        FL_h_heat_r2(i,j)=FL_alpha(i,j)/90*h_wall+(90-FL_alpha(i,j))/90*h_ceil_heat;    % htc in heating mode depending on slope angle [W/(m^2 K))]
        FL_h_cool_r2(i,j)=FL_alpha(i,j)/90*h_wall+(90-FL_alpha(i,j))/90*h_ceil_cool;    % htc in cooling mode depending on slope angle [W/(m^2 K))]
    end
end

% weighted area average convective heat transfer coefficient per loop %
FL_h_heat_r2_av(1:FL_numLoops)=0;
FL_h_cool_r2_av(1:FL_numLoops)=0;
for i=1:FL_numLoops
    for j=1:FL_numSubsections
        FL_h_heat_r2_av(i)=FL_h_heat_r2_av(i)+FL_h_heat_r2(i,j)*(FL_A_fl(i,j)/FL_A_fl_tot(i));      % [W/(m^2 K))]
        FL_h_cool_r2_av(i)=FL_h_cool_r2_av(i)+FL_h_cool_r2(i,j)*(FL_A_fl(i,j)/FL_A_fl_tot(i));      % [W/(m^2 K))]
    end
end


%%% upper surface, floor is flat (room 1) %%%
FL_h_heat_r1_av(1:FL_numLoops)=h_floor_heat;
FL_h_cool_r1_av(1:FL_numLoops)=h_floor_cool;


%% Roof TABS %%

%%% Global parameters and constants %%%

RO_numLayers=RO_layers{1,2}+1;          % number of layers
RO_numLoops=RO_geometry{1,2};           % number of loops
RO_numSubsections=RO_geometry{1,4};     % number of subsections

RO_theta_sw(1:RO_numLoops)=RO_geometry{1,6};    % supply water temperature [�C]
RO_m_dot=RO_geometry{1,8}*0.016667;             % supply water mass flow, from [L/min] to [kg/s]

RO_pipe_layer_location=RO_layers{3,2}+1;        % layer position of pipe

RO_d_x=RO_layers{1,6};          % pipe spacing [m]
RO_delta=RO_layers{1,4};        % pipe outside diameter [m]
RO_d_p=RO_layers{3,4};          % pipe thickness [m]

RO_lambda_p=RO_layers{3,6};                             % pipe thermal conductivity [W/(m K)]
RO_lambda_s=RO_layers{8+RO_pipe_layer_location,5};      % slab (pipe layer) thermal conductivity [W/(m K)]

U=MyInputs(11);     % wind speed [m/s]

RO_sigma=5.67032*10^-8;         % stefan-boltzmann constant [W/(m^2 K^4)]
RO_eps=0.88;                    % emissivity of roof

RO_f_sky(1:RO_numLoops)=0;
for i=1:RO_numLoops
    RO_f_sky(i)=1;              % view facotr to sky, 1 for horizontal roof parts
end
RO_f_sky(10)=0.5;               % view factor so sky, 0.5 for vertical roof part



% Store vertical layer values into matrices %

RO_rho(1:RO_numLayers-1)=0;
RO_Cp(1:RO_numLayers-1)=0;
RO_lambda(1:RO_numLayers-1)=0;
RO_d_fix(1:RO_numLayers-1)=0;

for k=1:RO_numLayers-1
    
    RO_rho(k)=RO_layers{9+k,3};         % layer density [kg/m^3]
    
    RO_Cp(k)=RO_layers{9+k,4};          % layer specific heat capacity [J/(kg K)]
    
    RO_lambda(k)=RO_layers{9+k,5};      % layer thermal conductivity [W/(m K)]
    
    RO_d_fix(k)=RO_layers{9+k,6};       % layer thickness [m]
    
end


% Store loop values into matrices %
RO_A_fl(1:RO_numLoops,1:RO_numSubsections)=0;
RO_A_ta(1:RO_numLoops,1:RO_numSubsections)=0;
RO_alpha(1:RO_numLoops,1:RO_numSubsections)=0;
RO_p_len(1:RO_numLoops,1:RO_numSubsections)=0;
RO_d_var(1:RO_numLoops,1:RO_numSubsections)=0;
RO_edge_len(1:RO_numLoops,1:RO_numSubsections)=0;
RO_m_dot_sp(1:RO_numLoops,1:RO_numSubsections)=0;
RO_m_dot_sp_tot(1:RO_numLoops)=0;
RO_A_fl_tot(1:RO_numLoops)=0;
RO_A_ta_tot(1:RO_numLoops)=0;

for i=1:RO_numLoops
    for j=1:RO_numSubsections
        
        RO_A_fl(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,2};        % floor area of subsection [m^2]
        
        RO_A_ta(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,6};        % activated TABS area of subsection [m^2]
        
        RO_A_fl_tot(i)=RO_A_fl_tot(i)+RO_A_fl(i,j);                     % total floor area of loop [m^2]
        
        RO_A_ta_tot(i)=RO_A_ta_tot(i)+RO_A_ta(i,j);                     % total activated TABS area of loop [m^2]
        
        RO_alpha(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,3};       % slope of subsection [�]
        
        RO_p_len(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,4};       % pipe length per subsection [m]
        
        RO_d_var(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,5};       % varying thickness across subsections of layer at position: pipe_layer_location-2 [m]
        
        RO_m_dot_sp(i,j)=RO_m_dot/(RO_d_x*RO_p_len(i,j));               % specific mass flow per subsection [kg/(s m^2)]
        
        RO_m_dot_sp_tot(i)=RO_m_dot/(RO_d_x*sum(RO_p_len(i,:)));        % specific mass flow per loop [kg/(s m^2)]
        
        RO_edge_len(i,j)=RO_geometry{(i-1)*RO_numSubsections+5+j,7};    % exposed edge length per subsection [m]
        
        RO_edge_loss=RO_geometry{1,10};                                 % edge loss coefficient [W/(m K)]
        
    end
end


%%%%%%% HORIZONTAL average/no average difference START %%%%%% 
% RO_A_fl(:,1)=RO_A_fl_tot(:);
% RO_A_ta(:,1)=RO_A_ta_tot(:);
% 
% RO_alpha_avg(1:RO_numLoops)=0;
% for i=1:RO_numLoops
%     for j=1:RO_numSubsections
%         RO_alpha_avg(i)=RO_alpha_avg(i)+RO_alpha(i,j)*RO_A_fl(i,j)/RO_A_fl_tot(i);
%     end
% end
% RO_alpha(:,1)=RO_alpha_avg(:);
% 
% 
% RO_d_var_avg(1:RO_numLoops)=0;
% for i=1:RO_numLoops
%     for j=1:RO_numSubsections
%         RO_d_var_avg(i)=RO_d_var_avg(i)+RO_d_var(i,j)*RO_A_fl(i,j)/RO_A_fl_tot(i);
%     end
% end
% RO_d_var(:,1)=RO_d_var_avg(:);
% 
% 
% for i=1:RO_numLoops
%     RO_p_len(i,1)=sum(RO_p_len(i,:));
% end
% 
% for i=1:RO_numLoops
%     RO_edge_len(i,1)=sum(RO_edge_len(i,:));
% end
% 
% RO_numSubsections=1;
%%%%%%% HORIZONTAL average/no average difference END %%%%%%


% Calculate R and C values %

RO_R_z(1:RO_numLoops)=0;
RO_R_w(1:RO_numLoops,1:RO_numSubsections)=0;
RO_R_p(1:RO_numLoops,1:RO_numSubsections)=0;
RO_R_x(1:RO_numLoops,1:RO_numSubsections)=0;
RO_R_t(1:RO_numLoops,1:RO_numSubsections)=0;
RO_R_el(1:RO_numLoops,1:RO_numSubsections)=0;
RO_R_layer_s(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers-1)=0;
RO_R_layer_u(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers-1)=0;
RO_C_layer_s(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers-1)=0;
RO_C_layer_u(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers-1)=0;
RO_sum_quot__1__R_t(1:RO_numLoops,1)=0;

for i=1:RO_numLoops
    for j=1:RO_numSubsections
        for k=1:RO_numLayers-1
            
            % Calculate horizontal resistance values %
            
            RO_R_z(i)=RO_A_fl_tot(i)/RO_A_ta_tot(i)*1/(2*RO_m_dot_sp_tot(i)*c_w);                                                           % resistance: supply water temp - mean water temp  [(m^2 K)/W)]
            
            RO_R_w(i,j)=RO_A_fl_tot(i)/RO_A_ta(i,j)*RO_d_x/(pi*lambda_w)*(49.03+4.17+4/pi*(RO_m_dot_sp(i,j)*c_w*RO_d_x)/lambda_w)^(-1/3); % resistance: mean water temp (pipe circular middle) - pipe inside wall surface temp [(m^2 K)/W)]
            
            RO_R_p(i,j)=RO_A_fl_tot(i)/RO_A_ta(i,j)*RO_d_x*log(RO_delta/(RO_delta-2*RO_d_p))/(2*RO_lambda_p*pi);                        % resistance: inside pipe wall surface temp - outside pipe wall surface temp [(m^2 K)/W)]
            
            RO_R_x(i,j)=RO_A_fl_tot(i)/RO_A_ta(i,j)*RO_d_x*1/3*(RO_d_x/(pi*RO_delta))/(2*RO_lambda_s*pi);                               % resistance: outside pipe wall surface temp - core temp  [(m^2 K)/W)]
            
            RO_R_t(i,j)=RO_R_w(i,j)+RO_R_p(i,j)+RO_R_x(i,j);                                                                            % total resistance: mean water temp - core temp [(m^2 K)/W)]
            
            RO_R_el(i,j)=RO_edge_loss*RO_edge_len(i,j);
            
            % Calculate resistance value matrix for vertical layers %
            
            RO_R_layer_s(i,j,k)=RO_A_fl_tot(i)/RO_A_ta(i,j)*RO_d_fix(k)/RO_lambda(k);                                                                   % activated TABS layer resistance [(m^2 K)/W)]
            
            RO_R_layer_s(i,j,RO_pipe_layer_location-2)=RO_A_fl_tot(i)/RO_A_ta(i,j)*RO_d_var(i,j)/RO_lambda(RO_pipe_layer_location-2);                   % activated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            RO_R_layer_u(i,j,k)=RO_A_fl_tot(i)/(RO_A_fl(i,j)-RO_A_ta(i,j))*RO_d_fix(k)/RO_lambda(k);                                                    % unactivated TABS layer resistance [(m^2 K)/W)]
            
            RO_R_layer_u(i,j,RO_pipe_layer_location-2)=RO_A_fl_tot(i)/(RO_A_fl(i,j)-RO_A_ta(i,j))*RO_d_var(i,j)/RO_lambda(RO_pipe_layer_location-2);    % unactivated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            % Calculate capacitance value matrix for vertical layers %
            
            if k==1 || k==2 || k==RO_numLayers-1                    % top side: 2 layers merged and averaged to surface layer, bottom side: 1 layer is surface layer (capacitance extends over subsections to whole loop -> no area ratio)
                
                RO_C_layer_s(i,j,k)=RO_d_fix(k)*RO_rho(k)*RO_Cp(k); % activated TABS layer capacitance [W/(m^2 K))]
                
                RO_C_layer_u(i,j,k)=RO_C_layer_s(i,j,k);            % unactivated TABS layer capacitance [W/(m^2 K))]
                
            elseif k==RO_pipe_layer_location-2 % for layer with varying thickness d_var
                
                RO_C_layer_s(i,j,k)=RO_A_ta(i,j)/RO_A_fl_tot(i)*RO_d_var(i,j)*RO_rho(k)*RO_Cp(k);                  % activated TABS layer capacitance [W/(m^2 K))]
                
                RO_C_layer_u(i,j,k)=(RO_A_fl(i,j)-RO_A_ta(i,j))/RO_A_fl_tot(i)*RO_d_var(i,j)*RO_rho(k)*RO_Cp(k);   % unactivated TABS layer capacitance [W/(m^2 K))]
                
            else % all other layers
                
                RO_C_layer_s(i,j,k)=RO_A_ta(i,j)/RO_A_fl_tot(i)*RO_d_fix(k)*RO_rho(k)*RO_Cp(k);                  % activated TABS layer capacitance [W/(m^2 K))]
                
                RO_C_layer_u(i,j,k)=(RO_A_fl(i,j)-RO_A_ta(i,j))/RO_A_fl_tot(i)*RO_d_fix(k)*RO_rho(k)*RO_Cp(k);   % unactivated TABS layer capacitance [W/(m^2 K))]
                
            end
        end
        
        RO_sum_quot__1__R_t(i)=RO_sum_quot__1__R_t(i)+(1/RO_R_t(i,j));      % summing up all the 1/R_t from each subsection per loop for later usage in calculations [W/(m^2 K))]
        
    end
end

% merging layers %

RO_numLayers=RO_numLayers-2;  % losing two layers since merging
RO_pipe_layer_location=RO_pipe_layer_location-2;  % moving up pipe layer location

for i=1:RO_numLoops
    for j=1:RO_numSubsections
        
        % adding resistance and capacitance values of layers to be merged
        % 1 and 2 into position 1
        RO_R_layer_s(i,j,1)=RO_R_layer_s(i,j,1)+RO_R_layer_s(i,j,2);
        RO_R_layer_u(i,j,1)=RO_R_layer_u(i,j,1)+RO_R_layer_u(i,j,2);
        RO_C_layer_s(i,j,1)=RO_C_layer_s(i,j,1)+RO_C_layer_s(i,j,2);
        RO_C_layer_u(i,j,1)=RO_C_layer_u(i,j,1)+RO_C_layer_u(i,j,2);
        
        % 3 and 4 into position 2
        RO_R_layer_s(i,j,2)=RO_R_layer_s(i,j,3)+RO_R_layer_s(i,j,4);
        RO_R_layer_u(i,j,2)=RO_R_layer_u(i,j,3)+RO_R_layer_u(i,j,4);
        RO_C_layer_s(i,j,2)=RO_C_layer_s(i,j,3)+RO_C_layer_s(i,j,4);
        RO_C_layer_u(i,j,2)=RO_C_layer_u(i,j,3)+RO_C_layer_u(i,j,4);
        
        % 5 into position 3
        RO_R_layer_s(i,j,3)=RO_R_layer_s(i,j,5);
        RO_R_layer_u(i,j,3)=RO_R_layer_u(i,j,5);
        RO_C_layer_s(i,j,3)=RO_C_layer_s(i,j,5);
        RO_C_layer_u(i,j,3)=RO_C_layer_u(i,j,5);
        
        
    end
end


%%% Inside heat transfer coefficient calculations %%%
RO_h_heat_r2(1:FL_numLoops,1:FL_numSubsections)=0;
RO_h_cool_r2(1:FL_numLoops,1:FL_numSubsections)=0;
for i=1:RO_numLoops
    for j=1:RO_numSubsections
        RO_h_heat_r2(i,j)=RO_alpha(i,j)/90*h_wall+(90-RO_alpha(i,j))/90*h_ceil_heat;    % htc in heating mode depending on slope angle [W/(m^2 K))]
        RO_h_cool_r2(i,j)=RO_alpha(i,j)/90*h_wall+(90-RO_alpha(i,j))/90*h_ceil_cool;    % htc in cooling mode depending on slope angle [W/(m^2 K))]
    end
end


% weighted area average convective heat transfer coefficient per loop %
RO_h_heat_r2_av(1:RO_numLoops)=0;
RO_h_cool_r2_av(1:RO_numLoops)=0;
for i=1:RO_numLoops
    for j=1:FL_numSubsections
        RO_h_heat_r2_av(i)=RO_h_heat_r2_av(i)+RO_h_heat_r2(i,j)*(RO_A_fl(i,j)/RO_A_fl_tot(i));  % [W/(m^2 K))]
        RO_h_cool_r2_av(i)=RO_h_cool_r2_av(i)+RO_h_cool_r2(i,j)*(RO_A_fl(i,j)/RO_A_fl_tot(i));  % [W/(m^2 K))]
    end
end

% weighted area average convective heat transfer coefficient per surface %

% sum up total horizontal roof area
RO_A_fl_tot_roof=0;
for i=1:RO_numLoops-1 % 9 loops for horizontal part
    RO_A_fl_tot_roof=RO_A_fl_tot_roof+RO_A_fl_tot(i);       % total horizontal roof area [m^2]
end

% apply weighted average
RO_h_heat_r2_av_hor=0;
RO_h_cool_r2_av_hor=0;
for i=1:RO_numLoops-1
    RO_h_heat_r2_av_hor=RO_h_heat_r2_av_hor+RO_h_heat_r2_av(i)*(RO_A_fl_tot(i)/RO_A_fl_tot_roof);   % [W/(m^2 K))]
    RO_h_cool_r2_av_hor=RO_h_cool_r2_av_hor+RO_h_cool_r2_av(i)*(RO_A_fl_tot(i)/RO_A_fl_tot_roof);   % [W/(m^2 K))]
end

% for vertical roof part only 1 loop %
RO_h_heat_r2_av_ver=RO_h_heat_r2_av(10);    % [W/(m^2 K))]
RO_h_cool_r2_av_ver=RO_h_cool_r2_av(10);    % [W/(m^2 K))]


%% Ventilation %%

% reading in data from input file %

main_ahu1_state=ventilation{3,5};               % state of AHU 1 in main space
main_ahu2_state=ventilation{4,5};               % state of AHU 2 in main space
off1_ahu_state=ventilation{6,5};                % state of AHU in office 1
off2_ahu_state=ventilation{7,5};                % state of AHU in office 2
main_ahu1_research_state=ventilation{9,5};      % state of research AHU in main space

main_ahu1_state_hr=ventilation{3,6};            % state of heat recovery of AHU 1 in main space
main_ahu2_state_hr=ventilation{4,6};            % state of heat recovery of AHU 2 in main space
off1_ahu_state_hr=ventilation{6,6};             % state of heat recovery of AHU in office 1
off2_ahu_state_hr=ventilation{7,6};             % state of heat recovery of AHU in office 2
main_ahu1_research_state_hr=ventilation{9,6};   % state of heat recovery of reserach AHU in main space

off1_off1_ret_perc=ventilation{13,5};           % percentage of total return mass flow from AHU in office 1 for return point in office 1
off1_kitch_ret_perc=ventilation{14,5};          % percentage of total return mass flow from AHU in office 1 for return point in kitchen
off1_off1_sup_perc=ventilation{15,5};           % percentage of total supply mass flow from AHU in office 1 for supply point in office 1
off1_main_sup_perc=ventilation{16,5};           % percentage of total supply mass flow from AHU in office 1 for supply point in main space

off2_off2_ret_perc=ventilation{19,5};           % percentage of total return mass flow from AHU in office 2 for return point in office 2
off2_tech_ret_perc=ventilation{20,5};           % percentage of total return mass flow from AHU in office 2 for return point in tech room
off2_off2_sup_perc=ventilation{21,5};           % percentage of total supply mass flow from AHU in office 2 for supply point in office 2
off2_main_sup_perc=ventilation{22,5};           % percentage of total supply mass flow from AHU in office 2 for supply point in main space

win1=ventilation{3,2};              % state of window 1
win2=ventilation{4,2};              % state of window 2
win3=ventilation{5,2};              % state of window 3
win4=ventilation{6,2};              % state of window 4
win5=ventilation{7,2};              % state of window 5
win6=ventilation{8,2};              % state of window 6
win7=ventilation{9,2};              % state of window 7
terrace_door=ventilation{10,2};     % state of terrace door

tech_room_door=ventilation{12,2};   % state of door: tech room - office 2
kitch_door=ventilation{13,2};       % state of door: kitchen - main space
off1_door=ventilation{14,2};        % state of door: office 1 - main space
off2_door=ventilation{15,2};        % state of door: office 2 - main space




%% E-Glass %%


winID=e_glass{2,2};         % window glazing ID for tinting state


%% Occupancy Schedule %%

main_occ=occupancy{2,2};        % occupancy rate for main space
off1_occ=occupancy{3,2};        % occupancy rate for office 1
off2_occ=occupancy{4,2};        % occupancy rate for office 2

main_pc=occupancy{2,3};         % number of PCs in main space
off1_pc=occupancy{3,3};         % number of PCs in office 1
off2_pc=occupancy{4,3};         % number of PCs in office 2

tech_heat=occupancy{6,2};       % heating power of electronic equipment in tech room [W]

heat_pp=115;        % average heat production per person in office buildings [W] (ASHRAE Handbook Fundamentals 2001)
heat_pc=240;        % average heat production per pc [W] (TRNSYS)

co2_pp=0.0048*(1.98/10^3);      % average co2 production per person in office buildings, from [L/(s Person)] to [kg/(s Person)] (DOI: 10.1111/ina.12383)


mFileErrorCode = 110;    % After processing inputs


%%%% First call of the simulation: initial time step (no iterations) %%%%


if ( (trnInfo(7) == 0) & (trnTime-trnStartTime < 1e-6) )
    
    %% Floor TABS %%
    
    % Initial values %
    
    FL_theta_bar_w(1:FL_numLoops)=20;       % floor TABS mean water temperature [�C]
    FL_theta_rw(1:FL_numLoops)=0;           % floor TABS return water temperature [�C]
    
    FL_theta_layer_s(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers)=20;      % floor TABS activated layer temperatures [�C]
    FL_theta_layer_u(1:FL_numLoops,1:FL_numSubsections,1:FL_numLayers)=20;      % floor TABS unactivated layer temperatures [�C]
    
    
    %% Roof TABS %%
    
    % Initial values %
    
    
    RO_theta_bar_w(1:RO_numLoops)=20;       % roof TABS mean water temperature [�C]
    RO_theta_rw(1:RO_numLoops)=20;          % roof TABS return water temperature [�C]
    
    RO_theta_layer_s(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers)=20;      % roof TABS activated layer temperatures [�C]
    RO_theta_layer_u(1:RO_numLoops,1:RO_numSubsections,1:RO_numLayers)=20;      % roof TABS unactivated layer temperatures [�C]
    
    RO_theta_layer_s_avg=20;            % roof TABS averaged inside surface temperature [�C]
    RO_theta_layer_core_hor_avg=20;     % roof TABS averaged core temperature [�C]
    
    %% E-Glass %%
    
    
    winID=0;        % window ID for glazing tinting state
    
    
    
    %% Occupancy Schedule %%
    
    
    time_of_day=-dt/3600;       % counter that that resets every 24 hours to know what time of the day it is for occupancy schedule, negative 1 timestep to reach 0 after adding 1 timestep in first call
    
    mFileErrorCode = 120;    % After initialization call
    
end


% --- Very last call of the simulation (after the user clicks "OK") ----------------------------------------------------
% ----------------------------------------------------------------------------------------------------------------------

if ( trnInfo(8) == -1 )
    
    mFileErrorCode = 1000;
    
    % Do stuff at the end of the simulation, e.g. calculate stats, draw plots, etc...
    
    % nothing to do here
    
    mFileErrorCode = 0; % Tell TRNSYS that we reached the end of the m-file without errors
    return
    
end


% --- Post convergence calls: store values -----------------------------------------------------------------------------
% ----------------------------------------------------------------------------------------------------------------------

if (trnInfo(13) == 1)
    
    mFileErrorCode = 200;   % Beginning of a post-convergence call
    
    % nothing to do here
    
    mFileErrorCode = 0; % Tell TRNSYS that we reached the end of the m-file without errors
    return
    
end


% --- All iterative calls ----------------------------------------------------------------------------------------------
% ----------------------------------------------------------------------------------------------------------------------

% --- If this is a first call in the time step, do things like incrementing step counters ---

% all calculations are done in here, this way we force the code to be run
% only once per timestep, as is necessary for our calculations

if ( trnInfo(7) == 0 )
    
    
    
    %% Basic Control Switches for First Simulations %%
    
    RO_theta_oa=MyInputs(6);        % outside air temperature [�C]
    
    
    % global system variables to directly control all outputs of natural ventilation, mechanical
    % ventilation and TABS
    nat_vent=0;         % state of natural ventilation (affects all windows and terrace door)
    mech_vent=0;        % state of mechanical ventilation (affects massflows of all AHUs)
    tabs=0;             % state of TABS (affects all TABS mass flows)
    
    
    % simulation test case for night cooling, turn on specific system after
    % 72 hours into the week
    if trnTime>=5544
        nat_vent=0;
        mech_vent=0;
        tabs=0;
    end
    
        time_of_day=time_of_day+dt/3600;    % increasing time of day counter depending on size of timestep
    
    % resetting time of day counter after 24 hours
    if time_of_day==24
        time_of_day=0;
    end
    
    
    % for TABS control
    if 1.00<=time_of_day && time_of_day<8.00
        tabs=1;
    else
        tabs=0;
    end
    
    % if TABS are off, mass flow is 0, therefore R_z becomes infinity
    if tabs==0
        FL_R_z(:)=Inf;
        RO_R_z(:)=Inf;
    end
    
    
    
    
    %% TABS Floor %%
    
    %%%% running the model %%%%
    
    % heat flux from inside surface to room and other surfaces
    FL_q_surf1(1)=MyInputs(1)/(-3.6);       % change its flow direction -> heat flux to floor TABS 1 main space surface, from [kJ/h] to [W]
    FL_q_surf2(1)=MyInputs(2)/(-3.6);       % change its flow direction -> heat flux to floor TABS 1 office 1 surface, from [kJ/h] to [W]
    FL_q_surf1(2)=MyInputs(3)/(-3.6);       % change its flow direction -> heat flux to floor TABS 2 main space surface, from [kJ/h] to [W]
    FL_q_surf2(2)=MyInputs(4)/(-3.6);       % change its flow direction -> heat flux to floor TABS 2 office 2 surface, from [kJ/h] to [W]
    
    FL_theta_r2(1)=MyInputs(12);            % air temperature office 1 [�C]
    
    FL_theta_r1(1)=MyInputs(13);            % air temperature main space [�C]
    FL_theta_r1(2)=MyInputs(13);            % air temperature main space [�C], same as FL_theta_r1_(1), new variable defined to be consequent with variables later in code
    
    FL_theta_r2(2)=MyInputs(14);            % air temperature office 2 [�C]
    
    
    % choosing htc depending on heating or cooling case
    % heating case is when wall temperature is higher than air temperature, for cooling vice versa
    
    FL_h_r1_av(1:FL_numLoops)=0;
    FL_h_r2_av(1:FL_numLoops)=0;
    
    for i=1:FL_numLoops
        if FL_theta_r1(i)>FL_theta_layer_s(i,1,1)               % TABS 1 and TABS 2 facing room 1 (main space) htc
            FL_h_r1_av(i)=FL_h_cool_r1_av(i);
        else
            FL_h_r1_av(i)=FL_h_heat_r1_av(i);
        end
        
        if FL_theta_r2(i)>FL_theta_layer_s(i,1,FL_numLayers)    % TABS 1 and TABS 2 facing room 2 (office 1 or office 2) htc
            FL_h_r2_av(i)=FL_h_cool_r2_av(i);
        else
            FL_h_r2_av(i)=FL_h_heat_r2_av(i);
        end
    end
    
    % running TABS floor model %
    
    FL_sum_quot__theta_core__R_t(1:FL_numLoops)=0;
    FL_sum_heat_fluxes_to_cores(1:FL_numLoops)=0;
    FL_sum_heat_fluxes_to_surf1(1:FL_numLoops)=0;
    FL_sum_heat_fluxes_to_surf2(1:FL_numLoops)=0;
    
    for i=1:FL_numLoops
        for j=1:FL_numSubsections
            
            FL_sum_quot__theta_core__R_t(i)=FL_sum_quot__theta_core__R_t(i)+(FL_theta_layer_s(i,j,FL_pipe_layer_location)/FL_R_t(i,j)); % summation of theta_core/R_t for each subsection, will be used for mean water temp calculation later in code
            
            FL_sum_heat_fluxes_to_cores(i)=FL_sum_heat_fluxes_to_cores(i)+1/FL_R_t(i,j)*(FL_theta_bar_w(i)-FL_theta_layer_s(i,j,FL_pipe_layer_location)); % summation of all heat fluxes to cores for each subsection, will be used for return water temp calculation later in code
            
            % depending on layer configuration, there are 4 cases for the
            % calculations of the heat fluxes to surface layers, refer to
            % the described cases in the reports appendix
            if FL_numLayers-FL_pipe_layer_location==1 && FL_pipe_layer_location~=2      % case 1
                FL_sum_heat_fluxes_to_surf1(i)=FL_sum_heat_fluxes_to_surf1(i)+(1/FL_R_layer_s(i,j,1)*(FL_theta_layer_s(i,j,2)-FL_theta_layer_s(i,j,1))+1/FL_R_layer_u(i,j,1)*(FL_theta_layer_u(i,j,2)-FL_theta_layer_u(i,j,1)));                            % heat flux to upper surface
                FL_sum_heat_fluxes_to_surf2(i)=FL_sum_heat_fluxes_to_surf2(i)+(1/FL_R_layer_s(i,j,FL_numLayers-1)*(FL_theta_layer_s(i,j,FL_numLayers-1)-FL_theta_layer_s(i,j,FL_numLayers))+1/(FL_R_layer_u(i,j,FL_numLayers-1)+FL_R_layer_u(i,j,FL_numLayers-2))*(FL_theta_layer_u(i,j,FL_numLayers-2)-FL_theta_layer_u(i,j,FL_numLayers)));   % heat flux to lower surface
                
            elseif FL_pipe_layer_location==2 && FL_numLayers-FL_pipe_layer_location==1  % case 2
                FL_sum_heat_fluxes_to_surf1(i)=FL_sum_heat_fluxes_to_surf1(i)+(1/FL_R_layer_s(i,j,1)*(FL_theta_layer_s(i,j,2)-FL_theta_layer_s(i,j,1))+1/(FL_R_layer_u(i,j,1)+FL_R_layer_u(i,j,2))*(FL_theta_layer_u(i,j,3)-FL_theta_layer_u(i,j,1)));      % heat flux to upper surface
                FL_sum_heat_fluxes_to_surf2(i)=FL_sum_heat_fluxes_to_surf2(i)+(1/FL_R_layer_s(i,j,FL_numLayers-1)*(FL_theta_layer_s(i,j,FL_numLayers-1)-FL_theta_layer_s(i,j,FL_numLayers))+1/(FL_R_layer_u(i,j,FL_numLayers-1)+FL_R_layer_u(i,j,FL_numLayers-2))*(FL_theta_layer_u(i,j,FL_numLayers-2)-FL_theta_layer_s(i,j,FL_numLayers)));   % heat flux to lower surface
                
            elseif FL_numLayers-FL_pipe_layer_location~=1 && FL_pipe_layer_location==2  % case 3
                FL_sum_heat_fluxes_to_surf1(i)=FL_sum_heat_fluxes_to_surf1(i)+(1/FL_R_layer_s(i,j,1)*(FL_theta_layer_s(i,j,2)-FL_theta_layer_s(i,j,1))+1/(FL_R_layer_u(i,j,1)+FL_R_layer_u(i,j,2))*(FL_theta_layer_u(i,j,3)-FL_theta_layer_u(i,j,1)));      % heat flux to upper surface
                FL_sum_heat_fluxes_to_surf2(i)=FL_sum_heat_fluxes_to_surf2(i)+(1/FL_R_layer_s(i,j,FL_numLayers-1)*(FL_theta_layer_s(i,j,FL_numLayers-1)-FL_theta_layer_s(i,j,FL_numLayers))+1/FL_R_layer_u(i,j,FL_numLayers-1)*(FL_theta_layer_u(i,j,FL_numLayers-1)-FL_theta_layer_u(i,j,FL_numLayers)));                                      % heat flux to lower surface
                
            else                                                                        % case 4
                FL_sum_heat_fluxes_to_surf1(i)=FL_sum_heat_fluxes_to_surf1(i)+(1/FL_R_layer_s(i,j,1)*(FL_theta_layer_s(i,j,2)-FL_theta_layer_s(i,j,1))+1/FL_R_layer_u(i,j,1)*(FL_theta_layer_u(i,j,2)-FL_theta_layer_u(i,j,1)));                            % heat flux to upper surface
                FL_sum_heat_fluxes_to_surf2(i)=FL_sum_heat_fluxes_to_surf2(i)+(1/FL_R_layer_s(i,j,FL_numLayers-1)*(FL_theta_layer_s(i,j,FL_numLayers-1)-FL_theta_layer_s(i,j,FL_numLayers))+1/FL_R_layer_u(i,j,FL_numLayers-1)*(FL_theta_layer_u(i,j,FL_numLayers-1)-FL_theta_layer_u(i,j,FL_numLayers)));                                      % heat flux to lower surface
                
            end
            
        end
        
        FL_theta_bar_w(i)=(FL_theta_sw(i)/FL_R_z(i)+FL_sum_quot__theta_core__R_t(i))/(1/FL_R_z(i)+FL_sum_quot__1__R_t(i)); % mean water temp calculation
        
        FL_theta_rw(i)=FL_theta_bar_w(i)-FL_sum_heat_fluxes_to_cores(i)/(FL_m_dot_sp_tot(i)*c_w); % return water temp calulation
        
        % surface temperature calculations, takes heat flux from TABS model
        % to surface layer and heat flux from TRNSYS to inside surface into consideration
        for j=1:FL_numSubsections
            
            FL_theta_layer_s(i,j,1)=FL_theta_layer_s(i,j,1)+dt/FL_C_layer_s(i,j,1)*(1*FL_sum_heat_fluxes_to_surf1(i)+FL_q_surf1(i)/FL_A_fl_tot(i));                                         % top surface temp
            
            FL_theta_layer_s(i,j,FL_numLayers)=FL_theta_layer_s(i,j,FL_numLayers)+dt/FL_C_layer_s(i,j,FL_numLayers-1)*(1*FL_sum_heat_fluxes_to_surf2(i)+FL_q_surf2(i)/FL_A_fl_tot(i));      % bottom surface temp
            
            FL_theta_layer_u(i,j,1)=FL_theta_layer_s(i,j,1);                            % uniform temperature in top surface layer
            
            FL_theta_layer_u(i,j,FL_numLayers)=FL_theta_layer_s(i,j,FL_numLayers);      % uniform temperature in bottom surface layer
            
        end
    end
    
    % Vertical layer temperatures %
    
    for i=1:FL_numLoops
        for j=1:FL_numSubsections
            for k=1:FL_numLayers
                
                % activated TABS area %
                % 3 different temperature calculation cases
                if 1<k && k<FL_pipe_layer_location                  % for layers between top surface layer and pipe layer
                    FL_theta_layer_s(i,j,k)=FL_theta_layer_s(i,j,k)+dt/FL_C_layer_s(i,j,k)*(1/FL_R_layer_s(i,j,k)*(FL_theta_layer_s(i,j,k+1)-FL_theta_layer_s(i,j,k))+1/FL_R_layer_s(i,j,k-1)*(FL_theta_layer_s(i,j,k-1)-FL_theta_layer_s(i,j,k)));
                    
                elseif k==FL_pipe_layer_location                    % pipe layer
                    FL_theta_layer_s(i,j,k)=(FL_theta_bar_w(i)/FL_R_t(i,j)+FL_theta_layer_s(i,j,k-1)/FL_R_layer_s(i,j,k-1)+FL_theta_layer_s(i,j,k+1)/FL_R_layer_s(i,j,k))/(1/FL_R_t(i,j)+1/FL_R_layer_s(i,j,k)+1/FL_R_layer_s(i,j,k-1));
                    
                elseif FL_pipe_layer_location<k && k<FL_numLayers   % for layers between pipe layer and bottom surface layer
                    FL_theta_layer_s(i,j,k)=FL_theta_layer_s(i,j,k)+dt/FL_C_layer_s(i,j,k-1)*(1/FL_R_layer_s(i,j,k)*(FL_theta_layer_s(i,j,k+1)-FL_theta_layer_s(i,j,k))+1/FL_R_layer_s(i,j,k-1)*(FL_theta_layer_s(i,j,k-1)-FL_theta_layer_s(i,j,k)));
                    
                end
                
                % unactivated TABS area
                if FL_C_layer_u(i,j,:)~=0       % only calculate when unactivated area exists (by checking if capacitance exists)
                    if 1<k && k<FL_pipe_layer_location-1                    % for layers between top surface layer and layer above pipe layer
                        FL_theta_layer_u(i,j,k)=FL_theta_layer_u(i,j,k)+dt/FL_C_layer_u(i,j,k)*(1/FL_R_layer_u(i,j,k)*(FL_theta_layer_u(i,j,k+1)-FL_theta_layer_u(i,j,k))+1/FL_R_layer_u(i,j,k-1)*(FL_theta_layer_u(i,j,k-1)-FL_theta_layer_u(i,j,k)));
                        
                    elseif k==FL_pipe_layer_location-1 && k>1               % for layer above pipe layer and is not surface layer
                        FL_theta_layer_u(i,j,k)=FL_theta_layer_u(i,j,k)+dt/FL_C_layer_u(i,j,k)*(1/(FL_R_layer_u(i,j,k)+FL_R_layer_u(i,j,k+1))*(FL_theta_layer_u(i,j,k+2)-FL_theta_layer_u(i,j,k))+1/FL_R_layer_u(i,j,k-1)*(FL_theta_layer_u(i,j,k-1)-FL_theta_layer_u(i,j,k)));
                        
                    elseif k==FL_pipe_layer_location                        % pipe layer has no temperature node, NaN value helps when debugging
                        FL_theta_layer_u(i,j,k)=NaN;
                        
                    elseif k==FL_pipe_layer_location+1 && k<FL_numLayers    % for layer below pipe layer and not surface layer
                        FL_theta_layer_u(i,j,k)=FL_theta_layer_u(i,j,k)+dt/FL_C_layer_u(i,j,k-1)*(1/(FL_R_layer_u(i,j,k-1)+FL_R_layer_u(i,j,k-2))*(FL_theta_layer_u(i,j,k-2)-FL_theta_layer_u(i,j,k))+1/FL_R_layer_u(i,j,k)*(FL_theta_layer_u(i,j,k+1)-FL_theta_layer_u(i,j,k)));
                        
                    elseif FL_pipe_layer_location+1<k && k<FL_numLayers     % for layers between bottom surface layer and layer below pipe layer
                        FL_theta_layer_u(i,j,k)=FL_theta_layer_u(i,j,k)+dt/FL_C_layer_u(i,j,k-1)*(1/FL_R_layer_u(i,j,k-1)*(FL_theta_layer_u(i,j,k-1)-FL_theta_layer_u(i,j,k))+1/FL_R_layer_u(i,j,k)*(FL_theta_layer_u(i,j,k+1)-FL_theta_layer_u(i,j,k)));
                        
                    end
                end
            end
        end
    end
    
    
    % floor TABS outputs %
    
    MyResults(1)=FL_theta_layer_s(1,1,1);
    MyResults(2)=FL_theta_layer_s(1,1,FL_numLayers);
    MyResults(3)=FL_theta_layer_s(2,1,1);
    MyResults(4)=FL_theta_layer_s(2,1,FL_numLayers);
    
    MyResults(35)=FL_h_r1_av(1)*3.6;        % unit converions
    MyResults(36)=FL_h_r2_av(1)*3.6;        % unit converions
    MyResults(37)=FL_h_r2_av(2)*3.6;        % unit converions
    
    FL_off1_core=sum(FL_theta_layer_s(1,:,FL_pipe_layer_location))/FL_numSubsections;   % average floor office 1 core temperature
    FL_off2_core=sum(FL_theta_layer_s(2,:,FL_pipe_layer_location))/FL_numSubsections;   % average floor office 2 core temperature
    
    MyResults(94)=FL_off1_core;
    MyResults(95)=FL_off2_core;
    
    
    %% TABS Roof  %%
    
    %%%% running the model %%%%
    
    % outside solar heat flux
    RO_q_solar(1:RO_numLoops)=0;
    for i=1:RO_numLoops-1
        RO_q_solar(i)=MyInputs(5)/3.6*(RO_A_fl_tot(i)/RO_A_fl_tot_roof);     % divide total heat flux to horizontal inside roof surface proportionally to each TABS loop depending on its surface area, from [kJ/h] to [W]
    end
    RO_q_solar(10)=MyInputs(10)/3.6;                                         % heat flux to vertical inside roof surface, from [kJ/h] to [W]
    
    
    % heat flux from inside surface to room and other surfaces
    RO_q_surf2(1:RO_numLoops)=0;
    for i=1:RO_numLoops-1
        RO_q_surf2(i)=MyInputs(8)/(-3.6)*(RO_A_fl_tot(i)/RO_A_fl_tot_roof);     % change its flow direction, divide total heat flux to horizontal inside roof surface proportionally to each TABS loop depending on its surface area, from [kJ/h] to [W]
    end
    RO_q_surf2(10)=MyInputs(9)/(-3.6);                                          % change its flow direction, heat flux to vertical inside roof surface, from [kJ/h] to [W]
    
        
    RO_theta_sky=MyInputs(7);           % sky temperature [�C]
    RO_theta_ground=RO_theta_oa;        % simplification of ground temperature equal to ambient temperature [�C] (David Bradley, TRNSYS support)
    
    
    % view sky factor calculation
    RO_theta_f_sky(1:RO_numLoops)=0;
    for i=1:RO_numLoops
        RO_theta_f_sky(i)=(1-RO_f_sky(i))*RO_theta_ground-RO_f_sky(i)*RO_theta_sky;     % TRNSYS documentation
    end
    
    
    % choosing internal htc depending on heating or cooling case
    % heating case is when wall temperature is higher than air temperature, for cooling vice versa
    % horizontal roof part
    if FL_theta_r1(1)>RO_theta_layer_s(1,1,RO_numLayers)
        RO_h_in_av_hor=RO_h_cool_r2_av_hor;
    else
        RO_h_in_av_hor=RO_h_heat_r2_av_hor;
    end
    
    % vertical roof part
    if FL_theta_r1(1)>RO_theta_layer_s(10,1,RO_numLayers)
        RO_h_in_av_ver=RO_h_cool_r2_av_ver;
    else
        RO_h_in_av_ver=RO_h_heat_r2_av_ver;
    end
    
    
    % Calculating external htc depending on windspeed (DOI: 10.1016/j.enconman.2010.07.026)
    if U>5
        RO_h_ex_av=7.1*U^0.78;      % [W/(m^2 K)]
    else
        RO_h_ex_av=4*U+4.6;         % [W/(m^2 K)]
    end
    
    % running TABS roof model %
    
    RO_sum_quot__theta_core__R_t(1:RO_numLoops)=0;
    RO_sum_heat_fluxes_to_cores(1:RO_numLoops)=0;
    RO_sum_heat_fluxes_to_surf1(1:RO_numLoops)=0;
    RO_sum_heat_fluxes_to_surf2(1:RO_numLoops)=0;
    
    for i=1:RO_numLoops
        for j=1:RO_numSubsections
            
            RO_sum_quot__theta_core__R_t(i)=RO_sum_quot__theta_core__R_t(i)+(RO_theta_layer_s(i,j,RO_pipe_layer_location)/RO_R_t(i,j)); % summation of theta_core/R_t for each subsection, will be used for mean water temp calculation later in code
            
            RO_sum_heat_fluxes_to_cores(i)=RO_sum_heat_fluxes_to_cores(i)+1/RO_R_t(i,j)*(RO_theta_bar_w(i)-RO_theta_layer_s(i,j,RO_pipe_layer_location));% summation of all heat fluxes to cores for each subsection, will be used for return water temp calculation later in code
            
            % depending on layer configuration, there are 4 cases for the
            % calculations of the heat fluxes to surface layers, refer to
            % the described cases in the reports appendix
            if RO_numLayers-RO_pipe_layer_location==1 && RO_pipe_layer_location~=2      % case 1
                RO_sum_heat_fluxes_to_surf1(i)=RO_sum_heat_fluxes_to_surf1(i)+(1/RO_R_layer_s(i,j,1)*(RO_theta_layer_s(i,j,2)-RO_theta_layer_s(i,j,1))+1/RO_R_layer_u(i,j,1)*(RO_theta_layer_u(i,j,2)-RO_theta_layer_u(i,j,1)));                            % heat flux to upper surface
                RO_sum_heat_fluxes_to_surf2(i)=RO_sum_heat_fluxes_to_surf2(i)+(1/RO_R_layer_s(i,j,RO_numLayers-1)*(RO_theta_layer_s(i,j,RO_numLayers-1)-RO_theta_layer_s(i,j,RO_numLayers))+1/(RO_R_layer_u(i,j,RO_numLayers-1)+RO_R_layer_u(i,j,RO_numLayers-2))*(RO_theta_layer_u(i,j,RO_numLayers-2)-RO_theta_layer_u(i,j,RO_numLayers)));   % heat flux to lower surface
                
            elseif RO_pipe_layer_location==2 && RO_numLayers-RO_pipe_layer_location==1  % case 2
                RO_sum_heat_fluxes_to_surf1(i)=RO_sum_heat_fluxes_to_surf1(i)+(1/RO_R_layer_s(i,j,1)*(RO_theta_layer_s(i,j,2)-RO_theta_layer_s(i,j,1))+1/(RO_R_layer_u(i,j,1)+RO_R_layer_u(i,j,2))*(RO_theta_layer_u(i,j,3)-RO_theta_layer_u(i,j,1)));      % heat flux to upper surface
                RO_sum_heat_fluxes_to_surf2(i)=RO_sum_heat_fluxes_to_surf2(i)+(1/RO_R_layer_s(i,j,RO_numLayers-1)*(RO_theta_layer_s(i,j,RO_numLayers-1)-RO_theta_layer_s(i,j,RO_numLayers))+1/(RO_R_layer_u(i,j,RO_numLayers-1)+RO_R_layer_u(i,j,RO_numLayers-2))*(RO_theta_layer_u(i,j,RO_numLayers-2)-RO_theta_layer_s(i,j,RO_numLayers)));   % heat flux to lower surface
                
            elseif RO_numLayers-RO_pipe_layer_location~=1 && RO_pipe_layer_location==2  % case 3
                RO_sum_heat_fluxes_to_surf1(i)=RO_sum_heat_fluxes_to_surf1(i)+(1/RO_R_layer_s(i,j,1)*(RO_theta_layer_s(i,j,2)-RO_theta_layer_s(i,j,1))+1/(RO_R_layer_u(i,j,1)+RO_R_layer_u(i,j,2))*(RO_theta_layer_u(i,j,3)-RO_theta_layer_u(i,j,1)));      % heat flux to upper surface
                RO_sum_heat_fluxes_to_surf2(i)=RO_sum_heat_fluxes_to_surf2(i)+(1/RO_R_layer_s(i,j,RO_numLayers-1)*(RO_theta_layer_s(i,j,RO_numLayers-1)-RO_theta_layer_s(i,j,RO_numLayers))+1/RO_R_layer_u(i,j,RO_numLayers-1)*(RO_theta_layer_u(i,j,RO_numLayers-1)-RO_theta_layer_u(i,j,RO_numLayers)));                                      % heat flux to lower surface
                
            else                                                                        % case 4
                RO_sum_heat_fluxes_to_surf1(i)=RO_sum_heat_fluxes_to_surf1(i)+(1/RO_R_layer_s(i,j,1)*(RO_theta_layer_s(i,j,2)-RO_theta_layer_s(i,j,1))+1/RO_R_layer_u(i,j,1)*(RO_theta_layer_u(i,j,2)-RO_theta_layer_u(i,j,1)));                            % heat flux to upper surface
                RO_sum_heat_fluxes_to_surf2(i)=RO_sum_heat_fluxes_to_surf2(i)+(1/RO_R_layer_s(i,j,RO_numLayers-1)*(RO_theta_layer_s(i,j,RO_numLayers-1)-RO_theta_layer_s(i,j,RO_numLayers))+1/RO_R_layer_u(i,j,RO_numLayers-1)*(RO_theta_layer_u(i,j,RO_numLayers-1)-RO_theta_layer_u(i,j,RO_numLayers)));                                      % heat flux to lower surface
                
            end
            
        end
        
        RO_theta_bar_w(i)=(RO_theta_sw(i)/RO_R_z(i)+RO_sum_quot__theta_core__R_t(i))/(1/RO_R_z(i)+RO_sum_quot__1__R_t(i)); % mean water temp calculation
        RO_theta_rw(i)=RO_theta_bar_w(i)-RO_sum_heat_fluxes_to_cores(i)/(RO_m_dot_sp_tot(i)*c_w); % return water temp calulation
        
        % surface temperature calculations, takes heat flux from TABS model
        % to surface layer and heat flux from TRNSYS to inside surface into
        % consideration or solar heat flux, radiative heat flux to sky temp and
        % convective heat flux to outside air temp into consideration
        for j=1:RO_numSubsections
            
            RO_theta_layer_s(i,j,1)=RO_theta_layer_s(i,j,1)+dt/RO_C_layer_s(i,j,1)*(1*RO_sum_heat_fluxes_to_surf1(i)+RO_q_solar(i)/RO_A_fl_tot(i)+RO_h_ex_av*(RO_theta_oa-RO_theta_layer_s(i,j,1))+RO_sigma*RO_eps*(RO_theta_f_sky(i)^4-RO_theta_layer_s(i,j,1)^4));
            
            RO_theta_layer_s(i,j,RO_numLayers)=RO_theta_layer_s(i,j,RO_numLayers)+dt/RO_C_layer_s(i,j,RO_numLayers-1)*(1*RO_sum_heat_fluxes_to_surf2(i)+RO_q_surf2(i)/RO_A_fl_tot(i));
            
            RO_theta_layer_u(i,j,1)=RO_theta_layer_s(i,j,1);                            % uniform temperature in top surface layer
            
            RO_theta_layer_u(i,j,RO_numLayers)=RO_theta_layer_s(i,j,RO_numLayers);      % uniform temperature in bottom surface layer
            
        end
    end
    
    
    % Vertical layer temperatures %
    
    for i=1:RO_numLoops
        for j=1:RO_numSubsections
            for k=1:RO_numLayers
                
                % activated TABS area %
                % 3 different temperature calculation cases
                if 1<k && k<RO_pipe_layer_location                                          % for layers between top surface layer and pipe layer
                    RO_theta_layer_s(i,j,k)=RO_theta_layer_s(i,j,k)+dt/RO_C_layer_s(i,j,k)*(1/RO_R_layer_s(i,j,k)*(RO_theta_layer_s(i,j,k+1)-RO_theta_layer_s(i,j,k))+1/RO_R_layer_s(i,j,k-1)*(RO_theta_layer_s(i,j,k-1)-RO_theta_layer_s(i,j,k)));
                    
                elseif k==RO_pipe_layer_location && RO_R_el(i,j)~=0                         % pipe layer if edge loss is existent
                    RO_theta_layer_s(i,j,k)=(RO_theta_bar_w(i)/RO_R_t(i,j)+RO_theta_layer_s(i,j,k-1)/RO_R_layer_s(i,j,k-1)+RO_theta_layer_s(i,j,k+1)/RO_R_layer_s(i,j,k)+RO_theta_oa/RO_R_el(i,j))/(1/RO_R_t(i,j)+1/RO_R_layer_s(i,j,k)+1/RO_R_layer_s(i,j,k-1)+1/RO_R_el(i,j));
                    
                elseif k==RO_pipe_layer_location && RO_R_el(i,j)==0                         % pipe layer if edge loss is non existent
                    RO_theta_layer_s(i,j,k)=(RO_theta_bar_w(i)/RO_R_t(i,j)+RO_theta_layer_s(i,j,k-1)/RO_R_layer_s(i,j,k-1)+RO_theta_layer_s(i,j,k+1)/RO_R_layer_s(i,j,k))/(1/RO_R_t(i,j)+1/RO_R_layer_s(i,j,k)+1/RO_R_layer_s(i,j,k-1));
                    
                elseif RO_pipe_layer_location<k && k<RO_numLayers                           % for layers between pipe layer and bottom surface layer
                    RO_theta_layer_s(i,j,k)=RO_theta_layer_s(i,j,k)+dt/RO_C_layer_s(i,j,k-1)*(1/RO_R_layer_s(i,j,k)*(RO_theta_layer_s(i,j,k+1)-RO_theta_layer_s(i,j,k))+1/RO_R_layer_s(i,j,k-1)*(RO_theta_layer_s(i,j,k-1)-RO_theta_layer_s(i,j,k)));
                    
                end
                
                % unactivated TABS area
                if RO_C_layer_u(i,j,:)~=0       % only calculate when unactivated area exists (by checking if capacitance exists)
                    if 1<k && k<RO_pipe_layer_location-1                    % for layers between top surface layer and layer above pipe layer
                        RO_theta_layer_u(i,j,k)=RO_theta_layer_u(i,j,k)+dt/RO_C_layer_u(i,j,k)*(1/RO_R_layer_u(i,j,k)*(RO_theta_layer_u(i,j,k+1)-RO_theta_layer_u(i,j,k))+1/RO_R_layer_u(i,j,k-1)*(RO_theta_layer_u(i,j,k-1)-RO_theta_layer_u(i,j,k)));
                        
                    elseif k==RO_pipe_layer_location-1 && k>1               % for layer above pipe layer and is not surface layer
                        RO_theta_layer_u(i,j,k)=RO_theta_layer_u(i,j,k)+dt/RO_C_layer_u(i,j,k)*(1/(RO_R_layer_u(i,j,k)+RO_R_layer_u(i,j,k+1))*(RO_theta_layer_u(i,j,k+2)-RO_theta_layer_u(i,j,k))+1/RO_R_layer_u(i,j,k-1)*(RO_theta_layer_u(i,j,k-1)-RO_theta_layer_u(i,j,k)));
                        
                    elseif k==RO_pipe_layer_location                        % pipe layer has no temperature node, NaN value helps when debugging
                        RO_theta_layer_u(i,j,k)=NaN;
                        
                    elseif k==RO_pipe_layer_location+1 && k<RO_numLayers    % for layer below pipe layer and not surface layer
                        RO_theta_layer_u(i,j,k)=RO_theta_layer_u(i,j,k)+dt/RO_C_layer_u(i,j,k-1)*(1/(RO_R_layer_u(i,j,k-1)+RO_R_layer_u(i,j,k-2))*(RO_theta_layer_u(i,j,k-2)-RO_theta_layer_u(i,j,k))+1/RO_R_layer_u(i,j,k)*(RO_theta_layer_u(i,j,k+1)-RO_theta_layer_u(i,j,k)));
                        
                    elseif RO_pipe_layer_location+1<k && k<RO_numLayers     % for layers between bottom surface layer and layer below pipe layer
                        RO_theta_layer_u(i,j,k)=RO_theta_layer_u(i,j,k)+dt/RO_C_layer_u(i,j,k-1)*(1/RO_R_layer_u(i,j,k-1)*(RO_theta_layer_u(i,j,k-1)-RO_theta_layer_u(i,j,k))+1/RO_R_layer_u(i,j,k)*(RO_theta_layer_u(i,j,k+1)-RO_theta_layer_u(i,j,k)));
                        
                    end
                end
            end
        end
    end
    
    % averaging inside surface temperature 
    RO_theta_layer_s_avg=0;
    for i=1:RO_numLoops-1
        RO_theta_layer_s_avg=RO_theta_layer_s_avg+RO_theta_layer_s(i,1,RO_numLayers);
    end
    RO_theta_layer_s_avg=RO_theta_layer_s_avg/9;
    
    
    % averaging horizontal roof part core temperature
    RO_theta_layer_core_hor_avg=0;
    for i=1:RO_numLoops-1
        RO_theta_layer_core_hor_avg=RO_theta_layer_core_hor_avg+sum(RO_theta_layer_s(i,:,RO_pipe_layer_location))/RO_numSubsections;
    end
    RO_theta_layer_core_hor_avg=RO_theta_layer_core_hor_avg/9;
    
    % averaging vertical roof part core temperature
    RO_theta_layer_core_ver_avg=0;
    RO_theta_layer_core_ver_avg=RO_theta_layer_core_ver_avg+sum(RO_theta_layer_s(10,:,RO_pipe_layer_location))/RO_numSubsections;
    
    
    MyResults(5)=RO_theta_layer_s_avg;
    MyResults(6)=RO_theta_layer_s(10,1,RO_numLayers);
    MyResults(32)=RO_h_in_av_ver*3.6;                       % from [W/m^2] to [kJ/(h m^2]
    MyResults(33)=RO_h_in_av_hor*3.6;                       % from [W/m^2] to [kJ/(h m^2]
    
    MyResults(96)=RO_theta_layer_core_hor_avg;
    MyResults(97)=RO_theta_layer_core_ver_avg;
    %% Ventilation %%
    
    
    t_off1=MyInputs(12);            % temperature office 1 [�C]
    t_off2=MyInputs(14);            % temperature office 2 [�C]
    t_tech=MyInputs(22);            % temperature tech room [�C]
    t_kitch=MyInputs(21);           % temperature kitchen [�C]
    
    kitch_rel_h=MyInputs(23);       % relative humidity kitchen [%]
    kitch_h_ratio=MyInputs(24);     % humidity ratio kitchen
    tech_rel_h=MyInputs(25);        % relative humidity tech room [%]
    tech_h_ratio=MyInputs(26);      % humidity ratio tech room
    off1_rel_h=MyInputs(27);        % relative humidity office 1 [%]
    off1_h_ratio=MyInputs(28);      % humidity ratio office 1
    off2_rel_h=MyInputs(29);        % relative humidity office 2 [%]
    off2_h_ratio=MyInputs(30);      % humidity ratio office 2
    
    atm_p=MyInputs(15);         % atmospheric pressure [  ]
    off1_p=MyInputs(16);        % gauge pressure office 1
    kitch_p=MyInputs(17);       % gauge pressure kitchen
    main_p=MyInputs(18);        % gauge pressure main space
    tech_p=MyInputs(19);        % gauge pressure tech room
    off2_p=MyInputs(20);        % gauge pressure office 2
    
    
    % main space research ahu %
    if main_ahu1_research_state==2              % fast
        main_ahu1_research_flow=276.944;        % mass flow [kg/s]
        main_ahu1_research_sens_eff=0.79;       % sensible efficiency [%]
        main_ahu1_research_lat_eff=0.6725;      % latent efficiency [%]
    elseif main_ahu1_research_state==1          % slow
        main_ahu1_research_flow=221.556;
        main_ahu1_research_sens_eff=0.815;
        main_ahu1_research_lat_eff=0.7125;
    elseif main_ahu1_research_state==0          % off
        main_ahu1_research_flow=0;
        main_ahu1_research_sens_eff=0;
        main_ahu1_research_lat_eff=0;
    end
    
    % main space ahu 1 %
    if main_ahu1_state==6               % power mode
        main_ahu1_flow=129.61;          % mass flow [kg/s]
        main_ahu1_sens_eff=0;           % sensible efficiency [%]
        main_ahu1_lat_eff=0;            % latent efficiency [%]
    elseif main_ahu1_state==5
        main_ahu1_flow=109.393;
        main_ahu1_sens_eff=0.775;
        main_ahu1_lat_eff=0.695;
    elseif main_ahu1_state==4
        main_ahu1_flow=84.4681;
        main_ahu1_sens_eff=0.815;
        main_ahu1_lat_eff=0.7375;
    elseif main_ahu1_state==3
        main_ahu1_flow=59.5431;
        main_ahu1_sens_eff=0.855;
        main_ahu1_lat_eff=0.78;
    elseif main_ahu1_state==2
        main_ahu1_flow=39.88;
        main_ahu1_sens_eff=0.88;
        main_ahu1_lat_eff=0.8125;
    elseif main_ahu1_state==1
        main_ahu1_flow=24.925;
        main_ahu1_sens_eff=0.9;
        main_ahu1_lat_eff=0.835;
    elseif main_ahu1_state==0
        main_ahu1_flow=0;
        main_ahu1_sens_eff=0;
        main_ahu1_lat_eff=0;
    end
    main_ahu1_flow_sup_ret=main_ahu1_flow/2+main_ahu1_research_flow/4;      % mass flow per supply/return point of ahu 1 in main space
    
    
    % main ahu2 %
    if main_ahu2_state==6 % power mode, bypasses heat recovery
        main_ahu2_flow=129.61;
        main_ahu2_sens_eff=0;
        main_ahu2_lat_eff=0;
    elseif main_ahu2_state==5
        main_ahu2_flow=109.393;
        main_ahu2_sens_eff=0.775;
        main_ahu2_lat_eff=0.695;
    elseif main_ahu2_state==4
        main_ahu2_flow=84.4681;
        main_ahu2_sens_eff=0.815;
        main_ahu2_lat_eff=0.7375;
    elseif main_ahu2_state==3
        main_ahu2_flow=59.5431;
        main_ahu2_sens_eff=0.855;
        main_ahu2_lat_eff=0.78;
    elseif main_ahu2_state==2
        main_ahu2_flow=39.88;
        main_ahu2_sens_eff=0.88;
        main_ahu2_lat_eff=0.8125;
    elseif main_ahu2_state==1
        main_ahu2_flow=24.925;
        main_ahu2_sens_eff=0.9;
        main_ahu2_lat_eff=0.835;
    elseif main_ahu2_state==0
        main_ahu2_flow=0;
        main_ahu2_sens_eff=0;
        main_ahu2_lat_eff=0;
    end
    main_ahu2_flow_sup_ret=main_ahu2_flow/2+main_ahu1_research_flow/4;       % mass flow per supply/return point of ahu 2 in main space
    
    
    % off 1 ahu %
    if off1_ahu_state==6 % power mode, bypasses heat recovery
        off1_ahu_flow=129.61;
        off1_ahu_sens_eff=0;
        off1_ahu_lat_eff=0;
    elseif off1_ahu_state==5
        off1_ahu_flow=109.393;
        off1_ahu_sens_eff=0.775;
        off1_ahu_lat_eff=0.695;
    elseif off1_ahu_state==4
        off1_ahu_flow=84.4681;
        off1_ahu_sens_eff=0.815;
        off1_ahu_lat_eff=0.7375;
    elseif off1_ahu_state==3
        off1_ahu_flow=59.5431;
        off1_ahu_sens_eff=0.855;
        off1_ahu_lat_eff=0.78;
    elseif off1_ahu_state==2
        off1_ahu_flow=39.88;
        off1_ahu_sens_eff=0.88;
        off1_ahu_lat_eff=0.8125;
    elseif off1_ahu_state==1
        off1_ahu_flow=24.925;
        off1_ahu_sens_eff=0.9;
        off1_ahu_lat_eff=0.835;
    elseif off1_ahu_state==0
        off1_ahu_flow=0;
        off1_ahu_sens_eff=0;
        off1_ahu_lat_eff=0;
    end
    
    
    off1_off1_ret_flow=off1_ahu_flow*off1_off1_ret_perc;        % mass flow of return point in office 1 of office 1 ahu
    off1_kitch_ret_flow=off1_ahu_flow*off1_kitch_ret_perc;      % mass flow of return point in kitchen of office 1 ahu
    off1_off1_sup_flow=off1_ahu_flow*off1_off1_sup_perc;        % mass flow of supply point in office 1 of office 1 ahu
    off1_main_sup_flow=off1_ahu_flow*off1_main_sup_perc;        % mass flow of supply point in main space of office 1 ahu
    
    
    % off2 ahu %
    if off2_ahu_state==6 % power mode, bypasses heat recovery
        off2_ahu_flow=129.61;
        off2_ahu_sens_eff=0;
        off2_ahu_lat_eff=0;
    elseif off2_ahu_state==5
        off2_ahu_flow=109.393;
        off2_ahu_sens_eff=0.775;
        off2_ahu_lat_eff=0.695;
    elseif off2_ahu_state==4
        off2_ahu_flow=84.4681;
        off2_ahu_sens_eff=0.815;
        off2_ahu_lat_eff=0.7375;
    elseif off2_ahu_state==3
        off2_ahu_flow=59.5431;
        off2_ahu_sens_eff=0.855;
        off2_ahu_lat_eff=0.78;
    elseif off2_ahu_state==2
        off2_ahu_flow=39.88;
        off2_ahu_sens_eff=0.88;
        off2_ahu_lat_eff=0.8125;
    elseif off2_ahu_state==1
        off2_ahu_flow=24.925;
        off2_ahu_sens_eff=0.9;
        off2_ahu_lat_eff=0.835;
    elseif off2_ahu_state==0
        off2_ahu_flow=0;
        off2_ahu_sens_eff=0;
        off2_ahu_lat_eff=0;
    end
    
    off2_off2_ret_flow=off2_ahu_flow*off2_off2_ret_perc;        % mass flow of return point in office 2 of office 2 ahu
    off2_tech_ret_flow=off2_ahu_flow*off2_tech_ret_perc;        % mass flow of return point in tech room of office 2 ahu
    off2_off2_sup_flow=off2_ahu_flow*off2_off2_sup_perc;        % mass flow of supply point in office 2 of office 2 ahu
    off2_main_sup_flow=off2_ahu_flow*off2_main_sup_perc;        % mass flow of supply point in main space of office 2 ahu
    
    
    
    % heat recovery calculations %
    
    
    main_p_atm=atm_p+main_p/101325;         % add gage pressure to atmosphere pressure and convert pascal to atm
    atm_p_pa=atm_p*101325;                  % convert atm to pa for contam input
    
    off1_ahu_p_ret=atm_p+(off1_p*off1_off1_ret_perc+kitch_p*off1_kitch_ret_perc)/101325;        % weighted averaged pressure of return mass flow of office 1 ahu
    off1_ahu_t_ret=t_off1*off1_off1_ret_perc+t_kitch*off1_kitch_ret_perc;                       % weighted averaged temperature of return mass flow of office 1 ahu
    off1_ahu_h_ratio_ret=off1_h_ratio*off1_off1_ret_perc+kitch_h_ratio*off1_kitch_ret_perc;     % weighted averaged humidity ratio of return mass flow of office 1 ahu
    off1_ahu_rel_h_ret=off1_rel_h*off1_off1_ret_perc+kitch_rel_h*off1_kitch_ret_perc;           % weighted averaged relative humidity of return mass flow of office 1 ahu
    
    off2_ahu_p_ret=atm_p+(off2_p*off2_off2_ret_perc+tech_p*off2_tech_ret_perc)/101325;          % weighted averaged pressure of return mass flow of office 2 ahu
    off2_ahu_t_ret=t_off2*off2_off2_ret_perc+t_tech*off2_tech_ret_perc;                         % weighted averaged temperature of return mass flow of office 2 ahu
    off2_ahu_h_ratio_ret=off2_h_ratio*off2_off2_ret_perc+tech_h_ratio*off2_tech_ret_perc;       % weighted averaged humidity ratio of return mass flow of office 2 ahu
    off2_ahu_rel_h_ret=off2_rel_h*off2_off2_ret_perc+tech_rel_h*off2_tech_ret_perc;             % weighted averaged humidity ratio of return mass flow of office 2 ahu
    
    
    main_ahu1_oa=1;     % no recirculation of exhaust air
    
    main_ahu2_oa=1;     % no recirculation of exhaust air
    
    off1_ahu_oa=1;      % no recirculation of exhaust air
    
    off2_ahu_oa=1;      % no recirculation of exhaust air
    
    % ventilation outputs %
    
    MyResults(7)=win4*nat_vent;
    MyResults(8)=win5*nat_vent;
    MyResults(9)=win3*nat_vent;
    MyResults(12)=win2*nat_vent;
    MyResults(13)=win1*nat_vent;
    MyResults(14)=win6*nat_vent;
    MyResults(15)=main_ahu1_oa;
    MyResults(16)=main_ahu2_oa;
    
    MyResults(21)=tech_room_door;
    MyResults(22)=kitch_door;
    
    MyResults(25)=off1_door;
    MyResults(26)=off2_door;
    MyResults(27)=terrace_door*nat_vent;
    MyResults(28)=win7*nat_vent;
    MyResults(29)=off1_ahu_oa;
    MyResults(31)=off2_ahu_oa;
    
    MyResults(42)=main_ahu1_research_state_hr;
    MyResults(43)=main_ahu1_research_flow;
    MyResults(44)=main_ahu1_research_sens_eff;
    MyResults(45)=main_ahu1_research_lat_eff;
    
    MyResults(46)=main_ahu1_state_hr;
    MyResults(47)=main_ahu1_flow;
    MyResults(48)=main_ahu1_sens_eff;
    MyResults(49)=main_ahu1_lat_eff;
    MyResults(50)=main_ahu1_flow_sup_ret*mech_vent;
    
    MyResults(51)=main_ahu2_state_hr;
    MyResults(52)=main_ahu2_flow;
    MyResults(53)=main_ahu2_sens_eff;
    MyResults(54)=main_ahu2_lat_eff;
    MyResults(55)=main_ahu2_flow_sup_ret*mech_vent;
    
    MyResults(56)=off1_ahu_state_hr;
    MyResults(57)=off1_ahu_flow;
    MyResults(58)=off1_ahu_sens_eff;
    MyResults(59)=off1_ahu_lat_eff;
    MyResults(60)=0;
    
    MyResults(61)=off2_ahu_state_hr;
    MyResults(62)=off2_ahu_flow;
    MyResults(63)=off2_ahu_sens_eff;
    MyResults(64)=off2_ahu_lat_eff;
    MyResults(65)=0;
    
    
    MyResults(66)=off1_kitch_ret_flow*mech_vent;
    MyResults(67)=off2_tech_ret_flow*mech_vent;
    MyResults(68)=off1_off1_ret_flow*mech_vent;
    MyResults(69)=off1_main_sup_flow*mech_vent;
    
    MyResults(70)=off2_main_sup_flow*mech_vent;
    MyResults(71)=off2_off2_ret_flow*mech_vent;
    MyResults(72)=off1_off1_sup_flow*mech_vent;
    MyResults(73)=off2_off2_sup_flow*mech_vent;
    
    MyResults(74)=off1_ahu_p_ret ;
    MyResults(75)=off1_ahu_t_ret;
    MyResults(76)=off1_ahu_h_ratio_ret;
    MyResults(77)=off1_ahu_rel_h_ret;
    
    MyResults(78)=off2_ahu_p_ret ;
    MyResults(79)=off2_ahu_t_ret;
    MyResults(80)=off2_ahu_h_ratio_ret;
    MyResults(81)=off2_ahu_rel_h_ret;
    
    MyResults(82)=main_p_atm;
    MyResults(83)=atm_p_pa;
    
    
    
    %% E-Glass %%
    
    MyResults(23)=winID;
    
    %% Occupancy Schedule %%
    
    % co2 sensor levels (these can be used for a control algorithm) %
    
    off1_co2_sens=MyInputs(31);     % office 1 co2 mass fraction [kg/kg]
    off2_co2_sens=MyInputs(32);     % office 2 co2 mass fraction [kg/kg]
    main_co2_sens=MyInputs(33);     % main co2 mass fraction [kg/kg]
    kitch_co2_sens=MyInputs(34);    % kitch co2 mass fraction [kg/kg]
    tech_co2_sens=MyInputs(35);     % tech co2 mass fraction [kg/kg]
    
    % Heat gain %
    
    main_heat_gain=(main_occ*heat_pp+main_pc*heat_pc)*3.6;       % heat gain of persons and PCs into main space, from [W] to [kJ/h]
    off1_heat_gain=(off1_occ*heat_pp+off1_pc*heat_pc)*3.6;       % heat gain of persons and PCs into office 1, from [W] to [kJ/h]
    off2_heat_gain=(off2_occ*heat_pp+off2_pc*heat_pc)*3.6;       % heat gain of persons and PCs into office 2, from [W] to [kJ/h]
    tech_heat_gain=tech_heat*3.6;                                % heat gain of electronic equipment in tech room, from [W] to [kJ/h]
    
    % CO2 gain %
    
    main_co2_gain=main_occ*co2_pp;       % co2 gain of persons into main space [kg/s]
    off1_co2_gain=off1_occ*co2_pp;       % co2 gain of persons into office 1 [kg/s]
    off2_co2_gain=off2_occ*co2_pp;       % co2 gain of persons into office 2 [kg/s]
    kitch_co2_gain=0;                    % no co2 in kitchen (can be adjusted)
    tech_co2_gain=0;                     % no co2 in tech room
    

    
    % global occupancy variable that turns occupancy on/off depending on
    % time of day
    if 8.00<=time_of_day && time_of_day<12.00 || 13.00<=time_of_day && time_of_day<17.00
        occ_switch=1;
    else
        occ_switch=0;
    end
    

    
    
    MyResults(90)=off1_heat_gain*occ_switch;
    MyResults(91)=main_heat_gain*occ_switch;
    MyResults(92)=off2_heat_gain*occ_switch;
    MyResults(93)=tech_heat_gain*occ_switch;
    
    MyResults(17)=off1_co2_gain*occ_switch;
    MyResults(18)=off2_co2_gain*occ_switch;
    MyResults(19)=main_co2_gain*occ_switch;
    MyResults(30)=kitch_co2_gain*occ_switch;
    MyResults(20)=tech_co2_gain*occ_switch;
    
    
    mFileErrorCode = 130;   % Beginning of iterative call
    % Nothing to do here
    
end

% --- Process Inputs ---

mFileErrorCode = 140;   % Beginning of iterative call

% nothing to do here

% --- Set outputs ---

mFileErrorCode = 150;   % Beginning of setting outputs

trnOutputs(1:nO) = MyResults;


mFileErrorCode = 0; % Tell TRNSYS that we reached the end of the m-file without errors
return