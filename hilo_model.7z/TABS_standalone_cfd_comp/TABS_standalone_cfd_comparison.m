%%%%% This matlab script models general TABS for CFD comparison %%%%%

clear all
clc


% Reading in data from excel input file %

[~,~,geometry] = xlsread('TABS_configuration_cfd_comp.xlsx',2);     % horizontal geometry data

[~,~,layers] = xlsread('TABS_configuration_cfd_comp.xlsx',1);       % vertical geometry data

[~,~,cases] = xlsread('RC_Test_filled.xlsx');                       % cases with different inputs for cfd comparison



%%%% Global variables %%%%


numLayers=layers{1,2}+1;                % number of layers
numLoops=geometry{1,2};                 % number of loops
numSubsections=geometry{1,4};           % number of subsections


time=20000;         % do 20000 for steady state
numCases=112;       % number of cases with different inputs defined for cfd comparison

m_dot=geometry{1,6}*0.016667;           % supply water mass flow, from [L/min] to [kg/s]

pipe_layer_location=layers{3,2}+1;      % layer number of pipe

d_x=layers{1,6};                        % pipe spacing [m]
delta=layers{1,4};                      % pipe outside diameter [m]
d_p=layers{3,4};                        % pipe thickness [m]

lambda_p=layers{3,6};                           % pipe thermal conductivity [W/(m K)]
lambda_s=layers{8+pipe_layer_location,5};       % slab (pipe layer) thermal conductivity [W/(m K)]


dt=60;              % timestep [s]

c_w=4186;           % water specific heat capacity [J/(kg K)]
lambda_w=0.59;      % water thermal conductivity [W/(m K)]




% Store vertical layer values into matrices %

rho(1:numLayers-1)=0;
Cp(1:numLayers-1)=0;
lambda(1:numLayers-1)=0;
d_fix(1:numLayers-1)=0;

for k=1:numLayers-1
    
    rho(k)=layers{9+k,3};           % layer density [kg/m^3]
    
    Cp(k)=layers{9+k,4};            % layer specific heat capacity [J/(kg K)]
    
    lambda(k)=layers{9+k,5};        % layer thermal conductivity [W/(m K)]
    
    d_fix(k)=layers{9+k,6};         % layer thickness [m]
    
end



% Store loop values into matrices %

A_fl(1:numLoops,1:numSubsections)=0;
A_ta(1:numLoops,1:numSubsections)=0;
alpha(1:numLoops,1:numSubsections)=0;
p_len(1:numLoops,1:numSubsections)=0;
d_var(1:numLoops,1:numSubsections)=0;
m_dot_sp(1:numLoops,1:numSubsections)=0;
m_dot_sp_tot(1:numLoops)=0;
A_fl_tot(1:numLoops)=0;
A_ta_tot(1:numLoops)=0;

for i=1:numLoops
    for j=1:numSubsections
        
        A_fl(i,j)=geometry{5+j,2};                              % floor area of subsection [m^2]
        
        A_ta(i,j)=geometry{(i-1)*numSubsections+5+j,6};         % activated TABS area of subsection [m^2]
        
        A_fl_tot(i)=A_fl_tot(i)+A_fl(i,j);                      % total floor area of loop [m^2]
        
        A_ta_tot(i)=A_ta_tot(i)+A_ta(i,j);                      % total activated TABS area of loop [m^2]
        
        alpha(i,j)=geometry{(i-1)*numSubsections+5+j,3};        % slope of subsection [�]
        
        p_len(i,j)=geometry{(i-1)*numSubsections+5+j,4};        % pipe length per subsection [m]
        
        d_var(i,j)=geometry{(i-1)*numSubsections+5+j,5};        % varying thickness across subsections of layer at position: pipe_layer_location-2 [m]
        
        m_dot_sp(i,j)=m_dot/(d_x*p_len(i,j));                   % specific mass flow per subsection [kg/(s m^2)]
        
        m_dot_sp_tot(i)=m_dot/(d_x*sum(p_len(i,:)));            % specific mass flow per loop [kg/(s m^2)]
        
    end
end


% Calculate R and C values %

R_z(1:numLoops)=0;
R_w(1:numLoops,1:numSubsections)=0;
R_p(1:numLoops,1:numSubsections)=0;
R_x(1:numLoops,1:numSubsections)=0;
R_t(1:numLoops,1:numSubsections)=0;
R_layer_s(1:numLoops,1:numSubsections,1:numLayers-1)=0;
R_layer_u(1:numLoops,1:numSubsections,1:numLayers-1)=0;
C_layer_s(1:numLoops,1:numSubsections,1:numLayers-1)=0;
C_layer_u(1:numLoops,1:numSubsections,1:numLayers-1)=0;
sum_quot__1__R_t(1:numLoops,1)=0;

for i=1:numLoops
    for j=1:numSubsections
        for k=1:numLayers-1
            
            % Calculate horizontal resistance values %
            
            R_z(i)=A_fl_tot(i)/A_ta_tot(i)*1/(2*m_dot_sp_tot(i)*c_w);                                                       % resistance: supply water temp - mean water temp  [(m^2 K)/W)]
            
            R_w(i,j)=A_fl_tot(i)/A_ta(i,j)*d_x/(pi*lambda_w)*(49.03+4.17+4/pi*(m_dot_sp(i,j)*c_w*d_x)/lambda_w)^(-1/3);     % resistance: mean water temp (pipe circular middle) - pipe inside wall surface temp [(m^2 K)/W)]
            
            R_p(i,j)=A_fl_tot(i)/A_ta(i,j)*d_x*log(delta/(delta-2*d_p))/(2*lambda_p*pi);                                    % resistance: inside pipe wall surface temp - outside pipe wall surface temp [(m^2 K)/W)]
            
            R_x(i,j)=A_fl_tot(i)/A_ta(i,j)*d_x*1/3*(d_x/(pi*delta))/(2*lambda_s*pi);                                        % resistance: outside pipe wall surface temp - core temp  [(m^2 K)/W)]
            
            R_t(i,j)=R_w(i,j)+R_p(i,j)+R_x(i,j);                                                                            % total resistance: mean water temp - core temp [(m^2 K)/W)]
            
            
            % Calculate resistance value matrix for vertical layers %
            
            R_layer_s(i,j,k)=A_fl_tot(i)/A_ta(i,j)*d_fix(k)/lambda(k);                                                          % activated TABS layer resistance [(m^2 K)/W)]
            
            R_layer_s(i,j,pipe_layer_location-2)=A_fl_tot(i)/A_ta(i,j)*d_var(i,j)/lambda(pipe_layer_location-2);                % activated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            R_layer_u(i,j,k)=A_fl_tot(i)/(A_fl(i,j)-A_ta(i,j))*d_fix(k)/lambda(k);                                              % unactivated TABS layer resistance [(m^2 K)/W)]
            
            R_layer_u(i,j,pipe_layer_location-2)=A_fl_tot(i)/(A_fl(i,j)-A_ta(i,j))*d_var(i,j)/lambda(pipe_layer_location-2);    % unactivated TABS layer resistance for layer with varying thickness [(m^2 K)/W)]
            
            
            % Calculate capacitance value matrix for vertical layers %
            
            if k==1 || k==numLayers-1                       % top side: first layer is surface layer, bottom side: last layer is surface layer (capacitance extends over subsections to whole loop -> no area ratio)
                
                C_layer_s(i,j,k)=d_fix(k)*rho(k)*Cp(k);     % activated TABS layer capacitance [W/(m^2 K))]
                
                C_layer_u(i,j,k)=C_layer_s(i,j,k);          % unactivated TABS layer capacitance [W/(m^2 K))]
                
            elseif k==pipe_layer_location-2                                                     % for layer with varying thickness d_var
                
                C_layer_s(i,j,k)=A_ta(i,j)/A_fl_tot(i)*d_var(i,j)*rho(k)*Cp(k);                 % activated TABS layer capacitance [W/(m^2 K))]
                
                C_layer_u(i,j,k)=(A_fl(i,j)-A_ta(i,j))/A_fl_tot(i)*d_var(i,j)*rho(k)*Cp(k);     % unactivated TABS layer capacitance [W/(m^2 K))]
                
            else                                                                            % for all other layers inbetween surfaces and not pipe layer
                
                C_layer_s(i,j,k)=A_ta(i,j)/A_fl_tot(i)*d_fix(k)*rho(k)*Cp(k);               % activated TABS layer capacitance [W/(m^2 K))]
                
                C_layer_u(i,j,k)=(A_fl(i,j)-A_ta(i,j))/A_fl_tot(i)*d_fix(k)*rho(k)*Cp(k);   % unactivated TABS layer capacitance [W/(m^2 K))]
                
            end
        end
        
        sum_quot__1__R_t(i)=sum_quot__1__R_t(i)+(1/R_t(i,j));           % summing up all the 1/R_t from each subsection per loop for later usage in calculations [W/(m^2 K))]
        
    end
end




%%% running each testcase %%%


theta_layer_s_data(1:numCases,1:numLayers)=0;


for c=1:numCases
    
    theta_sw(1:time+1,1)=cases{c+1,2};           % supply water temperature [�C]
    
    theta_ex(1:time+1)=cases{c+1,4};            % external temperature [�C] 
    theta_in(1:time+1)=cases{c+1,6};            % internal temperature [�C]
    
    ex_htc=cases{c+1,3};            % external heat transfer coefficient [W/(m^2 K))]
    in_htc=cases{c+1,5};            % external heat transfer coefficient [W/(m^2 K))]
    
    R_htc_ex=1/ex_htc;          % external resistance (reciprocate of htc) [(m^2 K)/W)]
    R_htc_in=1/in_htc;          % internal resistance (reciprocate of htc) [(m^2 K)/W)]
    
    pu_lower_lambda=cases{c+1,7};       % thermal conductivity of layer with varying thickness [W/(m K)]
    
    R_layer_s(i,j,pipe_layer_location-1)=A_fl_tot(i)/A_ta(i,j)*d_var(i,j)/pu_lower_lambda;      % resistance of layer with varying thickness
    
    
    
    % Initial values %
    
    theta_bar_w(1:time+1,1:numLoops)=20;
    theta_rw(1:time+1,1:numLoops)=20;
    
    theta_layer_s(1:time+1,1:numLoops,1:numSubsections,1:numLayers)=20;
    theta_layer_u(1:time+1,1:numLoops,1:numSubsections,1:numLayers)=20;
    
    
    
    
    %%% Running the model %%%
    
    
    sum_quot__theta_core__R_t(1:time,1:numLoops)=0;
    sum_heat_fluxes_to_cores(1:time,1:numLoops)=0;
    sum_heat_fluxes_to_surf1(1:time,1:numLoops)=0;
    sum_heat_fluxes_to_surf2(1:time,1:numLoops)=0;
    
    for t=1:time
        
        for i=1:numLoops
            for j=1:numSubsections
                sum_quot__theta_core__R_t(t,i)=sum_quot__theta_core__R_t(t,i)+(theta_layer_s(t,i,j,pipe_layer_location)/R_t(i,j));                      % summation of theta_core/R_t for each subsection, will be used for mean water temp calculation later in code
                sum_heat_fluxes_to_cores(t,i)=sum_heat_fluxes_to_cores(t,i)+1/R_t(i,j)*(theta_bar_w(t,i)-theta_layer_s(t,i,j,pipe_layer_location));     % summation of all heat fluxes to cores for each subsection, will be used for return water temp calculation later in code
                
                if numLayers-pipe_layer_location==1 && pipe_layer_location~=2       % case 1
                    sum_heat_fluxes_to_surf1(t,i)=sum_heat_fluxes_to_surf1(t,i)+(1/R_layer_s(i,j,1)*(theta_layer_s(t,i,j,2)-theta_layer_s(t,i,j,1))+1/R_layer_u(i,j,1)*(theta_layer_u(t,i,j,2)-theta_layer_u(t,i,j,1)));                            % heat flux to upper surface
                    sum_heat_fluxes_to_surf2(t,i)=sum_heat_fluxes_to_surf2(t,i)+(1/R_layer_s(i,j,numLayers-1)*(theta_layer_s(t,i,j,numLayers-1)-theta_layer_s(t,i,j,numLayers))+1/(R_layer_u(i,j,numLayers-1)+R_layer_u(i,j,numLayers-2))*(theta_layer_u(t,i,j,numLayers-2)-theta_layer_u(t,i,j,numLayers)));   % heat flux to lower surface
                elseif pipe_layer_location==2 && numLayers-pipe_layer_location==1   % case 2
                    sum_heat_fluxes_to_surf1(t,i)=sum_heat_fluxes_to_surf1(t,i)+(1/R_layer_s(i,j,1)*(theta_layer_s(t,i,j,2)-theta_layer_s(t,i,j,1))+1/(R_layer_u(i,j,1)+R_layer_u(i,j,2))*(theta_layer_u(t,i,j,3)-theta_layer_u(t,i,j,1)));         % heat flux to upper surface
                    sum_heat_fluxes_to_surf2(t,i)=sum_heat_fluxes_to_surf2(t,i)+(1/R_layer_s(i,j,numLayers-1)*(theta_layer_s(t,i,j,numLayers-1)-theta_layer_s(t,i,j,numLayers))+1/(R_layer_u(i,j,numLayers-1)+R_layer_u(i,j,numLayers-2))*(theta_layer_u(t,i,j,numLayers-2)-theta_layer_s(t,i,j,numLayers)));   % heat flux to lower surface
                elseif numLayers-pipe_layer_location~=1 && pipe_layer_location==2   % case 3
                    sum_heat_fluxes_to_surf1(t,i)=sum_heat_fluxes_to_surf1(t,i)+(1/R_layer_s(i,j,1)*(theta_layer_s(t,i,j,2)-theta_layer_s(t,i,j,1))+1/(R_layer_u(i,j,1)+R_layer_u(i,j,2))*(theta_layer_u(t,i,j,3)-theta_layer_u(t,i,j,1)));         % heat flux to upper surface
                    sum_heat_fluxes_to_surf2(t,i)=sum_heat_fluxes_to_surf2(t,i)+(1/R_layer_s(i,j,numLayers-1)*(theta_layer_s(t,i,j,numLayers-1)-theta_layer_s(t,i,j,numLayers))+1/R_layer_u(i,j,numLayers-1)*(theta_layer_u(t,i,j,numLayers-1)-theta_layer_u(t,i,j,numLayers)));                                % heat flux to lower surface
                else                                                                % case 4
                    sum_heat_fluxes_to_surf1(t,i)=sum_heat_fluxes_to_surf1(t,i)+(1/R_layer_s(i,j,1)*(theta_layer_s(t,i,j,2)-theta_layer_s(t,i,j,1))+1/R_layer_u(i,j,1)*(theta_layer_u(t,i,j,2)-theta_layer_u(t,i,j,1)));                            % heat flux to upper surface
                    sum_heat_fluxes_to_surf2(t,i)=sum_heat_fluxes_to_surf2(t,i)+(1/R_layer_s(i,j,numLayers-1)*(theta_layer_s(t,i,j,numLayers-1)-theta_layer_s(t,i,j,numLayers))+1/R_layer_u(i,j,numLayers-1)*(theta_layer_u(t,i,j,numLayers-1)-theta_layer_u(t,i,j,numLayers)));                                % heat flux to lower surface
                end
                
            end
            theta_bar_w(t+1,i)=(theta_sw(t,i)/R_z(i)+sum_quot__theta_core__R_t(t,i))/(1/R_z(i)+sum_quot__1__R_t(i)); % mean water temp calculation
            theta_rw(t+1,i)=theta_bar_w(t,i)-sum_heat_fluxes_to_cores(t,i)/(m_dot_sp_tot(i)*c_w); % return water temp calulation
            
            % surface temperature calculations, takes heat flux from TABS model
            % to surface layer and heat flux from TRNSYS to inside surface into consideration
            for j=1:numSubsections
                theta_layer_s(t+1,i,j,1)=theta_layer_s(t,i,j,1)+dt/C_layer_s(i,j,1)*(1*sum_heat_fluxes_to_surf1(t,i)+1/R_htc_ex(i)*(theta_ex(t)-theta_layer_s(t,i,j,1)));                                       % top surface temp
                theta_layer_s(t+1,i,j,numLayers)=theta_layer_s(t,i,j,numLayers)+dt/C_layer_s(i,j,numLayers-1)*(1*sum_heat_fluxes_to_surf2(t,i)+1/R_htc_in(i)*(theta_in(t)-theta_layer_s(t,i,j,numLayers)));     % bottom surface temp
                theta_layer_u(t+1,i,j,1)=theta_layer_s(t+1,i,j,1);                      % uniform temperature in top surface layer
                theta_layer_u(t+1,i,j,numLayers)=theta_layer_s(t+1,i,j,numLayers);      % uniform temperature in bottom surface layer
            end
        end
        
        % Vertical layer temperatures %
        
        for i=1:numLoops
            for j=1:numSubsections
                for k=1:numLayers
                    
                    % activated TABS area %
                    % 3 different temperature calculation cases
                    if 1<k && k<pipe_layer_location                     % for layers between top surface layer and pipe layer
                        theta_layer_s(t+1,i,j,k)=theta_layer_s(t,i,j,k)+dt/C_layer_s(i,j,k)*(1/R_layer_s(i,j,k)*(theta_layer_s(t,i,j,k+1)-theta_layer_s(t,i,j,k))+1/R_layer_s(i,j,k-1)*(theta_layer_s(t,i,j,k-1)-theta_layer_s(t,i,j,k)));
                    
                    elseif k==pipe_layer_location                       % pipe layer
                        theta_layer_s(t+1,i,j,k)=(theta_bar_w(t,i)/R_t(i,j)+theta_layer_s(t,i,j,k-1)/R_layer_s(i,j,k-1)+theta_layer_s(t,i,j,k+1)/R_layer_s(i,j,k))/(1/R_t(i,j)+1/R_layer_s(i,j,k)+1/R_layer_s(i,j,k-1));
                    
                    elseif pipe_layer_location<k && k<numLayers         % for layers between pipe layer and bottom surface layer
                        theta_layer_s(t+1,i,j,k)=theta_layer_s(t,i,j,k)+dt/C_layer_s(i,j,k-1)*(1/R_layer_s(i,j,k)*(theta_layer_s(t,i,j,k+1)-theta_layer_s(t,i,j,k))+1/R_layer_s(i,j,k-1)*(theta_layer_s(t,i,j,k-1)-theta_layer_s(t,i,j,k)));
                    
                    end
                    
                    % unactivated TABS area
                    if C_layer_u(i,j,:)~=0
                        if 1<k && k<pipe_layer_location-1                       % for layers between top surface layer and layer above pipe layer
                            theta_layer_u(t+1,i,j,k)=theta_layer_u(t,i,j,k)+dt/C_layer_u(i,j,k)*(1/R_layer_u(i,j,k)*(theta_layer_u(t,i,j,k+1)-theta_layer_u(t,i,j,k))+1/R_layer_u(i,j,k-1)*(theta_layer_u(t,i,j,k-1)-theta_layer_u(t,i,j,k)));
                        
                        elseif k==pipe_layer_location-1 && k>1                  % for layer above pipe layer and is not surface layer
                            theta_layer_u(t+1,i,j,k)=theta_layer_u(t,i,j,k)+dt/C_layer_u(i,j,k)*(1/(R_layer_u(i,j,k)+R_layer_u(i,j,k+1))*(theta_layer_u(t,i,j,k+2)-theta_layer_u(t,i,j,k))+1/R_layer_u(i,j,k-1)*(theta_layer_u(t,i,j,k-1)-theta_layer_u(t,i,j,k)));
                        
                        elseif k==pipe_layer_location                           % pipe layer has no temperature node, NaN value helps when debugging
                            theta_layer_u(t+1,i,j,k)=NaN;
                        
                        elseif k==pipe_layer_location+1 && k<numLayers          % for layer below pipe layer and not surface layer
                            theta_layer_u(t+1,i,j,k)=theta_layer_u(t,i,j,k)+dt/C_layer_u(i,j,k-1)*(1/(R_layer_u(i,j,k-1)+R_layer_u(i,j,k-2))*(theta_layer_u(t,i,j,k-2)-theta_layer_u(t,i,j,k))+1/R_layer_u(i,j,k)*(theta_layer_u(t,i,j,k+1)-theta_layer_u(t,i,j,k)));
                        
                        elseif pipe_layer_location+1<k && k<numLayers           % for layers between bottom surface layer and layer below pipe layer
                            theta_layer_u(t+1,i,j,k)=theta_layer_u(t,i,j,k)+dt/C_layer_u(i,j,k-1)*(1/R_layer_u(i,j,k-1)*(theta_layer_u(t,i,j,k-1)-theta_layer_u(t,i,j,k))+1/R_layer_u(i,j,k)*(theta_layer_u(t,i,j,k+1)-theta_layer_u(t,i,j,k)));
                        
                        end
                    end  
                end
            end
        end
    end
    
    % storing data for writing to excel sheet %
    
    theta_layer_s_data(c,1:numLayers)=theta_layer_s(time,1,1,1:numLayers);                                  % layer nodal temperatures
    theta_layer_s_data(c,numLayers+1)=theta_rw(time);                                                       % return water
    theta_layer_s_data(c,numLayers+2)=-1/R_htc_in(i)*(theta_in(time)-theta_layer_s(time,i,j,numLayers));    % inside heat flux
    theta_layer_s_data(c,numLayers+3)=-1/R_htc_ex(i)*(theta_ex(time)-theta_layer_s(time,i,j,1));            % external heat flux
    
    
end


% Write output to excel sheet %

xlswrite('RC_test_filled.xlsx',theta_layer_s_data,1,'H2');


% plot to check if steady state has reached %
timev=1:time+1;
for i=1:numLoops
    for j=1:numSubsections
        for k=1:numLayers
            figure(3)
            plot(timev,theta_layer_s(:,i,j,k));
            hold on
            Legend_s{i,j,k}=strcat('Theta layer s', num2str(i), num2str(j), num2str(k));
        end
        legend(Legend_s(i,j,:))
    end
end